"""Abstract base classes for database adaptors and dialects."""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Tuple, Optional

from eqlize.schema.models import Schema


class DatabaseAdaptor(ABC):
    """
    Runtime adaptor for database interaction.
    Handles connections, introspection, and raw query execution.
    """
    
    def __init__(self, connection_string: str):
        self.connection_string = connection_string
        self.connection = None
    
    @abstractmethod
    def connect(self):
        pass
    
    @abstractmethod
    def disconnect(self):
        pass
    
    @abstractmethod
    def introspect_schema(self) -> Schema:
        """Introspect the database to build a Schema object."""
        pass
    
    @abstractmethod
    def execute_query(self, sql: str) -> List[Dict[str, Any]]:
        """Execute a SQL query and return results."""
        pass


class SQLDialect(ABC):
    """
    Compile-time dialect for SQL generation.
    Handles syntax differences (quoting, JSON functions, operator mapping).
    """

    # --- Basic Syntax ---

    @abstractmethod
    def quote_identifier(self, identifier: str) -> str:
        """e.g. "table" or `table`"""
        pass
    
    @abstractmethod
    def quote_literal(self, value: Any) -> str:
        """e.g. 'value' or 123"""
        pass
    
    @abstractmethod
    def validate_operator(self, operator: str) -> None:
        """Raise error if operator is not supported."""
        pass

    # --- Structure ---

    @abstractmethod
    def limit_offset(self, limit: Optional[int], offset: Optional[int]) -> str:
        """Return the LIMIT/OFFSET clause."""
        pass

    # --- JSON Generation ---

    @abstractmethod
    def build_json_object(self, key_value_pairs: List[Tuple[str, str]]) -> str:
        """
        Generate SQL to create a JSON object.
        Args: list of (key_string, value_sql_expression)
        """
        pass

    @abstractmethod
    def build_json_array_agg(self, expression: str, distinct: bool = False, order_by: Optional[str] = None) -> str:
        """
        Generate SQL aggregate function for a scalar expression.
        Used for: list(.field) -> json_group_array(t1.field)
        """
        pass

    @abstractmethod
    def build_json_array_subquery(self, subquery_sql: str, agg_alias: str) -> str:
        """
        Generate SQL to wrap a subquery and aggregate a specific column into a JSON array.
        Used for: link_many -> (SELECT json_agg(agg_alias) FROM (subquery_sql) AS sub)
        """
        pass

    @abstractmethod
    def extract_json_element(self, json_expr: str, index: int) -> str:
        """Extract element from JSON array by index."""
        pass

    # --- Functions & Slicing ---

    @abstractmethod
    def compile_function(self, func_name: str, args: List[str], ctx_ctes: Dict[str, str]) -> str:
        """
        Compile a generic function name to dialect-specific SQL.
        Args:
            func_name: EdgeQL function name (e.g., 'str_split', 'len')
            args: List of already compiled SQL arguments
            ctx_ctes: Dictionary to register CTEs if the function requires them
        """
        pass

    @abstractmethod
    def compile_slice(self, base_sql: str, start: Optional[int], end: Optional[int], is_array: bool) -> str:
        """Handle string or array slicing semantics."""
        pass