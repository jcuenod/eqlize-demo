"""Data structures representing database schema."""

from dataclasses import dataclass, field
from typing import Optional, Dict
from enum import Enum


class FieldType(Enum):
    """SQL to EdgeQL type mapping."""
    INTEGER = "int64"
    BIGINT = "int64"
    SMALLINT = "int16"
    FLOAT = "float64"
    REAL = "float64"
    DOUBLE = "float64"
    TEXT = "str"
    VARCHAR = "str"
    CHAR = "str"
    BOOLEAN = "bool"
    BLOB = "bytes"
    DATE = "datetime"
    DATETIME = "datetime"
    TIMESTAMP = "datetime"
    
    @classmethod
    def from_sql_type(cls, sql_type: str) -> "FieldType":
        """Convert SQL type string to FieldType."""
        sql_type_upper = sql_type.upper().split('(')[0].strip()
        try:
            return cls[sql_type_upper]
        except KeyError:
            # Default to TEXT for unknown types
            return cls.TEXT


@dataclass
class Field:
    """Represents a field/column in an object type."""
    name: str
    type: FieldType
    nullable: bool = True
    is_primary_key: bool = False
    sql_column_name: str = ""  # Original SQL column name if different
    
    def __post_init__(self):
        if not self.sql_column_name:
            self.sql_column_name = self.name


@dataclass
class Link:
    """Represents a relationship/link between object types."""
    name: str  # Property name for the link
    target_type: str  # Name of the target object type
    source_column: str  # Foreign key column in source table
    target_column: str  # Referenced column in target table (usually 'id')
    cardinality: str = "single"  # 'single' or 'multi'
    
    
@dataclass
class BackLink:
    """Represents a reverse relationship."""
    name: str  # Property name for the backlink
    source_type: str  # The type that has the forward link
    forward_link_name: str  # Name of the forward link
    cardinality: str = "multi"  # Usually 'multi' for reverse links


@dataclass
class ObjectType:
    """Represents an inferred object type from a SQL table."""
    name: str  # EdgeQL-style name (PascalCase)
    table_name: str  # Original SQL table name
    fields: Dict[str, Field] = field(default_factory=dict)
    links: Dict[str, Link] = field(default_factory=dict)
    backlinks: Dict[str, BackLink] = field(default_factory=dict)
    
    def add_field(self, field_obj: Field):
        """Add a field to this object type."""
        self.fields[field_obj.name] = field_obj
    
    def add_link(self, link: Link):
        """Add a link to this object type."""
        self.links[link.name] = link
    
    def add_backlink(self, backlink: BackLink):
        """Add a backlink to this object type."""
        self.backlinks[backlink.name] = backlink


@dataclass
class Schema:
    """Complete database schema representation."""
    object_types: Dict[str, ObjectType] = field(default_factory=dict)
    
    def add_object_type(self, obj_type: ObjectType):
        """Add an object type to the schema."""
        self.object_types[obj_type.name] = obj_type
    
    def get_object_type(self, name: str) -> Optional[ObjectType]:
        """Get an object type by name."""
        return self.object_types.get(name)
    
    def __repr__(self):
        return f"Schema(types={list(self.object_types.keys())})"

    def to_dict(self) -> dict:
        """Convert the schema to a dictionary representation."""
        return {
            type_name: {
                "table_name": obj_type.table_name,
                "fields": {
                    field_name: {
                        "type": field.type.value,
                        "nullable": field.nullable,
                        "is_primary_key": field.is_primary_key,
                        "sql_column_name": field.sql_column_name
                    }
                    for field_name, field in obj_type.fields.items()
                },
                "links": {
                    link_name: {
                        "target_type": link.target_type,
                        "source_column": link.source_column,
                        "target_column": link.target_column,
                        "cardinality": link.cardinality
                    }
                    for link_name, link in obj_type.links.items()
                },
                "backlinks": {
                    backlink_name: {
                        "source_type": backlink.source_type,
                        "forward_link_name": backlink.forward_link_name,
                        "cardinality": backlink.cardinality
                    }
                    for backlink_name, backlink in obj_type.backlinks.items()
                }
            }
            for type_name, obj_type in self.object_types.items()
        }
