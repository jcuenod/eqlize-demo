"""Eqlize - EdgeQL to SQL compiler."""

__version__ = "0.1.0"
