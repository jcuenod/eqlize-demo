"""HTTP server for EdgeQL queries."""

import json
from http.server import HTTPServer as BaseHTTPServer, BaseHTTPRequestHandler
from typing import Optional
from ..adaptors import DatabaseAdaptor, SQLDialect
from ..parser import EdgeQLParser
from ..core import SQLCompiler
from ..output import JSONFormatter
from ..schema import Schema
from pyparsing import ParseException


class EdgeQLRequestHandler(BaseHTTPRequestHandler):
    """HTTP request handler for EdgeQL queries."""
    
    # These will be set by the HTTPServer class
    db_adaptor: DatabaseAdaptor
    sql_dialect: SQLDialect
    parser: EdgeQLParser
    schema: Schema
    compiler: SQLCompiler
    formatter: JSONFormatter
    
    def do_POST(self):
        """Handle POST requests with EdgeQL queries."""
        if self.path != '/query':
            self.send_error(404, "Not Found - use /query endpoint")
            return
        
        try:
            # Read request body
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length).decode('utf-8')
            
            # Parse JSON request
            try:
                request_data = json.loads(body)
            except json.JSONDecodeError as e:
                self.send_json_response(
                    {"error": f"Invalid JSON: {str(e)}"},
                    status=400
                )
                return
            
            # Get query from request
            query = request_data.get('query', '').strip()
            if not query:
                self.send_json_response(
                    {"error": "Missing 'query' field in request"},
                    status=400
                )
                return
            
            # Execute query
            result = self._execute_query(query)
            self.send_json_response(result)
            
        except Exception as e:
            self.send_json_response(
                {"error": f"Internal server error: {str(e)}"},
                status=500
            )
    
    def do_GET(self):
        """Handle GET requests - show API info."""
        if self.path == '/':
            self.send_json_response({
                "service": "Eqlize EdgeQL Server",
                "endpoints": {
                    "/query": "POST - Execute EdgeQL queries"
                },
                "usage": {
                    "method": "POST",
                    "endpoint": "/query",
                    "body": {"query": "SELECT People { name, age }"}
                }
            })
        else:
            self.send_error(404, "Not Found")
    
    def _execute_query(self, query: str) -> dict:
        """Execute an EdgeQL query and return results."""
        try:
            # Parse EdgeQL
            ast = self.parser.parse(query)
            
            # Compile to SQL
            sql = self.compiler.compile(ast)
            
            # Execute SQL
            results = self.db_adaptor.execute_query(sql)
            
            # Restructure results based on nested shapes
            results = self.compiler.restructure_results(results)
            
            return {
                "data": results,
                "sql": sql,
                "count": len(results)
            }
            
        except ParseException as e:
            return {
                "error": f"Parse error: {str(e)}",
                "type": "ParseError"
            }
        except Exception as e:
            import traceback
            return {
                "error": str(e),
                "type": type(e).__name__,
                "traceback": traceback.format_exc()
            }
    
    def send_json_response(self, data: dict, status: int = 200):
        """Send a JSON response."""
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        
        response_json = json.dumps(data, indent=2, default=str)
        self.wfile.write(response_json.encode('utf-8'))
    
    def log_message(self, format, *args):
        """Log HTTP requests."""
        # Format: "GET /query HTTP/1.1" 200 -
        print(f"[HTTP] {format % args}")


class HTTPServer:
    """HTTP server for EdgeQL queries."""
    
    def __init__(self, db_adaptor: DatabaseAdaptor, sql_dialect: SQLDialect, port: int = 8080):
        self.db_adaptor = db_adaptor
        self.sql_dialect = sql_dialect
        self.port = port
        self.parser = EdgeQLParser()
        self.schema: Optional[Schema] = None
        self.compiler: Optional[SQLCompiler] = None
        self.formatter = JSONFormatter()
        self.server: Optional[BaseHTTPServer] = None
    
    def start(self):
        """Start the HTTP server."""
        print("Eqlize - EdgeQL HTTP Server")
        print("=" * 50)
        
        # Connect and introspect schema
        print("Connecting to database...")
        self.db_adaptor.connect()
        
        print("Introspecting schema...")
        self.schema = self.db_adaptor.introspect_schema()
        
        print(f"Found {len(self.schema.object_types)} object types:")
        for type_name in self.schema.object_types.keys():
            print(f"  - {type_name}")
        
        print()
        
        # Initialize compiler
        self.compiler = SQLCompiler(self.schema, self.sql_dialect)
        
        # Set class attributes for request handler
        EdgeQLRequestHandler.db_adaptor = self.db_adaptor
        EdgeQLRequestHandler.sql_dialect = self.sql_dialect
        EdgeQLRequestHandler.parser = self.parser
        EdgeQLRequestHandler.schema = self.schema
        EdgeQLRequestHandler.compiler = self.compiler
        EdgeQLRequestHandler.formatter = self.formatter
        
        # Create and start server
        server_address = ('', self.port)
        self.server = BaseHTTPServer(server_address, EdgeQLRequestHandler)
        
        print(f"Server listening on http://localhost:{self.port}")
        print("Endpoints:")
        print("  GET  / - API information")
        print("  POST /query - Execute EdgeQL queries")
        print()
        print("Example request:")
        print(f'  curl -X POST http://localhost:{self.port}/query \\')
        print('       -H "Content-Type: application/json" \\')
        print('       -d \'{"query": "SELECT People { name, age }"}\'')
        print()
        print("Press Ctrl+C to stop the server")
        print()
        
        try:
            self.server.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server...")
        finally:
            self.stop()
    
    def stop(self):
        """Stop the HTTP server."""
        if self.server:
            self.server.shutdown()
            self.server.server_close()
        self.db_adaptor.disconnect()
        print("Server stopped")
