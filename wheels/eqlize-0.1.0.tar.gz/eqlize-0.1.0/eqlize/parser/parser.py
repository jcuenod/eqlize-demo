"""EdgeQL parser implementation using pyparsing."""

from typing import Union, cast
from pyparsing import (
    Word, alphas, alphanums,
    Literal, QuotedString,
    Group, Optional as PPOptional, OneOrMore,
    Forward, Suppress, pyparsing_common,
    delimitedList, CaselessKeyword,
    infixNotation, opAssoc,
    pythonStyleComment
)
from .ast_nodes import (
    SelectQuery, GroupQuery, Shape, ShapeElement, ShapeModifiers, WildcardElement,
    GroupShape, GroupShapeElement, Expression, PathExpression,
    FilterExpression, OrderByExpression, OrderByClause, LimitClause,
    GroupByClause, AggregateFunction, Identifier, OffsetClause,
    LiteralExpression, BinaryOpExpression, UnaryOpExpression, FunctionCall,
    IdentifierExpression, IndexExpression, SliceExpression
)


class EdgeQLParser:
    """Parser for EdgeQL queries."""
    
    def __init__(self):
        """Initialize the parser grammar."""
        self.grammar = self._build_grammar()
    
    def _build_grammar(self):
        """Build the pyparsing grammar for EdgeQL."""
        
        # Comments: defined early to be ignored later
        comment = pythonStyleComment

        # Keywords
        SELECT = CaselessKeyword("SELECT")
        GROUP = CaselessKeyword("GROUP")
        FILTER = CaselessKeyword("FILTER")
        ORDER = CaselessKeyword("ORDER")
        BY = CaselessKeyword("BY")
        ASC = CaselessKeyword("ASC")
        DESC = CaselessKeyword("DESC")
        LIMIT = CaselessKeyword("LIMIT")
        OFFSET = CaselessKeyword("OFFSET")
        AND = CaselessKeyword("AND")
        OR = CaselessKeyword("OR")
        NOT = CaselessKeyword("NOT")
        LIKE = CaselessKeyword("LIKE")
        ILIKE = CaselessKeyword("ILIKE")
        DISTINCT = CaselessKeyword("DISTINCT")
        
        # Basic tokens
        identifier = Word(alphas + "_", alphanums + "_")
        integer = pyparsing_common.signed_integer()
        number = pyparsing_common.number()
        string_literal = QuotedString("'", escChar="\\") | QuotedString('"', escChar="\\")
        
        # Boolean literals
        TRUE = CaselessKeyword("true")
        FALSE = CaselessKeyword("false")
        boolean_literal = (TRUE | FALSE)
        boolean_literal.setParseAction(lambda t: str(t[0]).lower() == 'true')
        
        # Path expression (.name, .person.name)
        path_component = Suppress(".") + identifier
        path_expr = Group(OneOrMore(path_component))
        path_expr.setParseAction(lambda t: PathExpression(list(t[0])))
        
        # Literal expression (combine all literal types)
        literal_expr = Forward()
        literal_value = string_literal | boolean_literal | number
        literal_expr <<= literal_value
        literal_expr.setParseAction(lambda t: LiteralExpression(t[0]))
        
        # Forward declaration for recursive expressions
        expression = Forward()
        
        # Function call: func_name(arg1, arg2, ...)
        # Need to be careful about argument parsing to support both identifiers and expressions
        func_call = Forward()
        
        # Function argument can be an expression (will be defined below) or a plain identifier
        plain_identifier = identifier.copy()
        plain_identifier.setParseAction(lambda t: IdentifierExpression(str(t[0])))
        
        # Basic atom (path, literal, identifier, function call, or parenthesized expression)
        base_atom = (
            func_call |
            path_expr | 
            literal_expr |
            plain_identifier |
            (Suppress("(") + expression + Suppress(")"))
        )
        
        # Now define function call (needs atom to be defined first for recursive arguments)
        func_call <<= Group(
            identifier + Suppress("(") + PPOptional(delimitedList(expression)) + Suppress(")")
        )
        def create_function_call(t):
            func_name = str(t[0][0])
            args = [arg for arg in t[0][1:] if isinstance(arg, Expression)]
            return FunctionCall(function_name=func_name, arguments=args)
        func_call.setParseAction(create_function_call)
        
        # Index/slice notation: [index] or [start:end]
        # Index can be a single integer (positive or negative)
        # Slice has format [start:end] where either can be omitted
        index_or_slice = Forward()
        
        # Slice: [start:end], [:end], [start:], or even [:]
        # The presence of a colon distinguishes it from a single index
        # We need to handle optional start and end
        slice_notation = (
            Suppress("[") + 
            PPOptional(integer) + 
            Literal(":") +  # Use Literal to ensure it's in the parse result for detection
            PPOptional(integer) + 
            Suppress("]")
        )
        
        # Single index: [5] or [-1]
        # No colon present
        single_index = Suppress("[") + integer + Suppress("]")
        
        # Try slice first (it has a colon), then single index
        index_or_slice <<= Group(slice_notation | single_index)
        
        # Atom with optional indexing/slicing (can be chained)
        atom = Forward()
        atom <<= Group(base_atom + PPOptional(OneOrMore(index_or_slice)))
        
        def create_indexed_atom(t):
            """Create an atom with optional index/slice operations."""
            if len(t[0]) == 1:
                # No indexing/slicing
                return t[0][0]
            
            # Start with base expression
            expr = t[0][0]
            
            # Apply each index/slice operation
            for idx_slice in t[0][1:]:
                # Check if this is a slice by looking for the colon
                has_colon = ':' in [str(x) for x in idx_slice]
                
                if has_colon:
                    # Slice notation - need to figure out which integers are before/after colon
                    # Find the position of the colon
                    colon_idx = None
                    for i, item in enumerate(idx_slice):
                        if str(item) == ':':
                            colon_idx = i
                            break
                    
                    # Extract start (before colon) and end (after colon)
                    start = None
                    end = None
                    
                    if colon_idx is not None:
                        # Check for integer before colon
                        if colon_idx > 0 and isinstance(idx_slice[colon_idx - 1], int):
                            start = idx_slice[colon_idx - 1]
                        # Check for integer after colon
                        if colon_idx < len(idx_slice) - 1 and isinstance(idx_slice[colon_idx + 1], int):
                            end = idx_slice[colon_idx + 1]
                    
                    expr = SliceExpression(expr, start, end)
                elif len(idx_slice) == 1:
                    # Single index
                    expr = IndexExpression(expr, idx_slice[0])
                else:
                    raise ValueError(f"Invalid index/slice: {idx_slice}")
            
            return expr
        
        atom.setParseAction(create_indexed_atom)
        
        # Comparison operators
        comp_op = (
            Literal("<=") | Literal(">=") | Literal("!=") | 
            Literal("=") | Literal("<") | Literal(">") |
            ILIKE | LIKE
        )
        
        # Build expression with proper operator precedence
        # Helper to build left-associative binary trees for operators with multiple operands
        def build_binary_tree(t):
            tokens = t[0]
            # tokens is [A, op, B, op, C, op, D, ...]
            # Build ((A op B) op C) op D) ... (left-associative)
            result = tokens[0]
            for i in range(1, len(tokens), 2):
                operator = tokens[i]
                right = tokens[i + 1]
                result = BinaryOpExpression(result, operator, right)
            return result
        
        expression <<= infixNotation(
            atom,
            [
                (comp_op, 2, opAssoc.LEFT, build_binary_tree),
                (NOT, 1, opAssoc.RIGHT, lambda t: UnaryOpExpression("NOT", t[0][1])),
                (AND, 2, opAssoc.LEFT, build_binary_tree),
                (OR, 2, opAssoc.LEFT, build_binary_tree),
            ]
        )
        
        # Aggregate function: list([distinct] path) [filter expression]
        aggregate_func = Group(
            identifier + 
            Suppress("(") + 
            PPOptional(DISTINCT) +
            path_expr + 
            Suppress(")") +
            PPOptional(FILTER + expression)
        )
        def create_aggregate_func(t):
            # Parse tokens: [func_name, [DISTINCT], path_expr, [FILTER, filter_expr]]
            idx = 1
            has_distinct = False
            
            # Check if DISTINCT is present
            if idx < len(t[0]) and isinstance(t[0][idx], str) and t[0][idx].upper() == "DISTINCT":
                has_distinct = True
                idx += 1
            
            # Get the path expression
            if idx >= len(t[0]):
                raise ValueError("Expected path expression in aggregate function")
            arg = t[0][idx]
            if not isinstance(arg, PathExpression):
                raise ValueError(f"Expected PathExpression, got {type(arg)}")
            idx += 1
            
            # Check for FILTER clause (FILTER keyword followed by expression)
            filt = None
            if idx < len(t[0]) and isinstance(t[0][idx], str) and t[0][idx].upper() == "FILTER":
                idx += 1  # Skip the FILTER keyword
                if idx < len(t[0]) and isinstance(t[0][idx], Expression):
                    filt = FilterExpression(t[0][idx])
            
            return AggregateFunction(
                function_name=str(t[0][0]),
                argument=arg,
                distinct=has_distinct,
                filter=filt
            )
        aggregate_func.setParseAction(create_aggregate_func)
        
        # Shape element
        wildcard = Literal("*")
        wildcard.setParseAction(lambda: WildcardElement())
        
        shape = Forward()
        
        # Forward declarations for nested modifiers
        filter_clause = Forward()
        order_by_clause = Forward()
        limit_clause = Forward()
        offset_clause = Forward()
        
        # Nested shape modifiers (filter, order by, limit, offset)
        nested_modifiers = (
            PPOptional(filter_clause) +
            PPOptional(order_by_clause) +
            PPOptional(limit_clause) +
            PPOptional(offset_clause)
        )
        
        def create_shape_modifiers(modifiers_list):
            """Create ShapeModifiers from a list of parsed modifier objects."""
            if not modifiers_list:
                return None
            
            mods = ShapeModifiers()
            for mod in modifiers_list:
                if isinstance(mod, FilterExpression):
                    mods.filter = mod
                elif isinstance(mod, OrderByClause):
                    mods.order_by = mod
                elif isinstance(mod, LimitClause):
                    mods.limit = mod
                elif isinstance(mod, OffsetClause):
                    mods.offset = mod
            
            # Only return if at least one modifier was set
            if mods.filter or mods.order_by or mods.limit or mods.offset:
                return mods
            return None
        
        # Simple property, computed property (with :=), or nested link with shape and modifiers
        shape_element = Group(
            identifier +
            PPOptional(
                (Suppress(":=") + expression) |
                (Suppress(":") + shape + nested_modifiers)
            )
        )
        def create_shape_element(t):
            name = str(t[0][0])
            shape_obj = None
            modifiers_obj = None
            alias = None
            expr_obj = None
            
            if len(t[0]) > 1:
                second_element = t[0][1]
                # Check if it's an expression (computed property with :=)
                if isinstance(second_element, Expression):
                    # This is a computed property: name := expression
                    # The name becomes the alias, and we store the expression
                    alias = name
                    expr_obj = second_element
                # Check if it's a shape (nested relationship)
                elif isinstance(second_element, Shape):
                    shape_obj = second_element
                    if not isinstance(shape_obj, Shape):
                        raise ValueError(f"Expected Shape, got {type(shape_obj)}")
                    
                    # Check for modifiers after shape
                    if len(t[0]) > 2:
                        modifiers_list = [m for m in t[0][2:] if isinstance(m, (FilterExpression, OrderByClause, LimitClause, OffsetClause))]
                        modifiers_obj = create_shape_modifiers(modifiers_list)
            
            return ShapeElement(
                name=name,
                shape=shape_obj,
                alias=alias,
                expression=expr_obj,
                modifiers=modifiers_obj
            )
        shape_element.setParseAction(create_shape_element)
        
        # Shape: { name, age, orders: { * } }
        shape_content = delimitedList(wildcard | shape_element)
        shape <<= Group(Suppress("{") + PPOptional(shape_content) + Suppress("}"))
        def create_shape(t):
            elements = [elem for elem in t[0] if isinstance(elem, (ShapeElement, WildcardElement))]
            return Shape(elements)
        shape.setParseAction(create_shape)
        
        # GROUP shape element: can be simple field, computed (name := expression), or nested (name: { shape })
        group_shape_element = Group(
            identifier +
            PPOptional(
                (Suppress(":=") + (aggregate_func | expression)) |
                (Suppress(":") + shape)
            )
        )
        def create_group_shape_element(t):
            name = str(t[0][0])
            if len(t[0]) > 1:
                second_element = t[0][1]
                # Check if it's a shape (nested relationship)
                if isinstance(second_element, Shape):
                    return GroupShapeElement(
                        name=name,
                        shape=second_element,
                        is_assignment=False
                    )
                # Otherwise it's an expression (assignment)
                elif isinstance(second_element, Expression):
                    return GroupShapeElement(
                        name=name,
                        expression=second_element,
                        is_assignment=True
                    )
                else:
                    raise ValueError(f"Expected Shape or Expression, got {type(second_element)}")
            else:
                # Simple field reference
                return GroupShapeElement(name=name)
        group_shape_element.setParseAction(create_group_shape_element)
        
        # GROUP shape: { rid, sg := list(word_uid) filter .number = "sg" }
        group_shape_content = delimitedList(wildcard | group_shape_element)
        group_shape = Group(Suppress("{") + PPOptional(group_shape_content) + Suppress("}"))
        def create_group_shape(t):
            elements = [elem for elem in t[0] if isinstance(elem, (GroupShapeElement, WildcardElement))]
            return GroupShape(elements)
        group_shape.setParseAction(create_group_shape)
        
        # GROUP BY clause
        group_by_clause = Group(BY + delimitedList(expression))
        def create_group_by_clause(t):
            expressions = [expr for expr in t[0][1:] if isinstance(expr, Expression)]
            return GroupByClause(expressions)
        group_by_clause.setParseAction(create_group_by_clause)
        
        # FILTER clause
        filter_clause <<= Group(FILTER + expression)
        def create_filter_expression(t):
            expr = t[0][1]
            if not isinstance(expr, Expression):
                raise ValueError(f"Expected Expression, got {type(expr)}")
            return FilterExpression(expr)
        filter_clause.setParseAction(create_filter_expression)
        
        # ORDER BY clause
        order_expr = Group(expression + PPOptional(ASC | DESC))
        def create_order_expr(t):
            expr = t[0][0]
            if not isinstance(expr, Expression):
                raise ValueError(f"Expected Expression, got {type(expr)}")
            return OrderByExpression(
                expr,
                str(t[0][1]).upper() if len(t[0]) > 1 else "ASC"
            )
        order_expr.setParseAction(create_order_expr)
        
        order_by_clause <<= Group(ORDER + BY + delimitedList(order_expr))
        def create_order_by_clause(t):
            expressions = [expr for expr in t[0][2:] if isinstance(expr, OrderByExpression)]
            return OrderByClause(expressions)
        order_by_clause.setParseAction(create_order_by_clause)
        
        # LIMIT clause
        limit_clause <<= Group(LIMIT + integer)
        def create_limit_clause(t):
            val = t[0][1]
            # pyparsing_common.signed_integer() already returns an int
            if not isinstance(val, int):
                val = int(val)
            return LimitClause(val)
        limit_clause.setParseAction(create_limit_clause)
        
        # OFFSET clause
        offset_clause <<= Group(OFFSET + integer)
        def create_offset_clause(t):
            val = t[0][1]
            # pyparsing_common.signed_integer() already returns an int
            if not isinstance(val, int):
                val = int(val)
            return OffsetClause(val)
        offset_clause.setParseAction(create_offset_clause)
        
        # SELECT query
        select_query = (
            SELECT +
            identifier +
            PPOptional(shape) +
            PPOptional(filter_clause) +
            PPOptional(order_by_clause) +
            PPOptional(limit_clause) +
            PPOptional(offset_clause)
        )
        
        def create_select_query(tokens):
            # Start with basic query (SELECT and identifier are always tokens[0] and [1])
            query = SelectQuery(target=Identifier(tokens[1]))
            
            # Process all optional tokens starting from index 2
            for token in tokens[2:]:
                if isinstance(token, Shape):
                    query.shape = token
                elif isinstance(token, FilterExpression):
                    query.filter = token
                elif isinstance(token, OrderByClause):
                    query.order_by = token
                elif isinstance(token, LimitClause):
                    query.limit = token
                elif isinstance(token, OffsetClause):
                    query.offset = token
            
            return query
        
        select_query.setParseAction(create_select_query)
        
        # GROUP query: group TypeName { fields/aggregates } by field
        group_query = (
            GROUP +
            identifier +
            PPOptional(group_shape) +
            group_by_clause +
            PPOptional(filter_clause) +
            PPOptional(order_by_clause) +
            PPOptional(limit_clause) +
            PPOptional(offset_clause)
        )
        
        def create_group_query(tokens):
            query = GroupQuery(
                target=Identifier(tokens[1]),
                shape=None,
                group_by=None
            )
            
            # Process tokens starting from index 2
            for token in tokens[2:]:
                if isinstance(token, GroupShape):
                    query.shape = token
                elif isinstance(token, GroupByClause):
                    query.group_by = token
                elif isinstance(token, FilterExpression):
                    query.filter = token
                elif isinstance(token, OrderByClause):
                    query.order_by = token
                elif isinstance(token, LimitClause):
                    query.limit = token
                elif isinstance(token, OffsetClause):
                    query.offset = token
            
            return query
        
        group_query.setParseAction(create_group_query)
        
        # Top-level query roots
        root = select_query | group_query
        
        # Support optional trailing semicolon
        query = root + PPOptional(Suppress(";"))
        
        # Support python-style comments (# ...)
        query.ignore(comment)
        
        return query
    
    def parse(self, query_string: str) -> Union[SelectQuery, GroupQuery]:
        """
        Parse an EdgeQL query string into an AST.
        
        Args:
            query_string: EdgeQL query string
            
        Returns:
            SelectQuery or GroupQuery AST node
            
        Raises:
            ParseException: If the query is invalid
        """
        result = self.grammar.parseString(query_string, parseAll=True)
        return cast(Union[SelectQuery, GroupQuery], result[0])