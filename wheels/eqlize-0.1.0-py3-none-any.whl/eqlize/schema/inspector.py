"""Schema introspection logic."""

from typing import Dict
from .models import Schema, ObjectType, Field, Link, BackLink, FieldType


def table_name_to_type_name(table_name: str) -> str:
    """Convert SQL table name to EdgeQL-style type name (PascalCase).

    NOTE: This function no longer attempts to singularize or pluralize names.
    It performs a deterministic snake_case -> PascalCase conversion so that
    introspection is predictable and not brittle.
    """
    # Simple conversion: snake_case -> PascalCase (preserve base name)
    return table_name.replace('_', ' ').title().replace(' ', '')


def column_name_to_field_name(column_name: str) -> str:
    """Convert SQL column name to EdgeQL-style field name (snake_case)."""
    return column_name.lower()


def infer_link_name(foreign_key_column: str, target_table: str) -> str:
    """Infer a reasonable link name from foreign key column and target table."""
    # If column is like 'person_id', return 'person'
    if foreign_key_column.endswith('_id'):
        return foreign_key_column[:-3]
    
    # Otherwise use the target table name converted to an identifier
    return table_name_to_type_name(target_table).lower()


def infer_backlink_name(source_table: str) -> str:
    """Infer a reasonable backlink name from source table."""
    # Use the source table name as a lowercase identifier for the backlink.
    return source_table.lower()


def build_schema_from_introspection(tables_info: Dict, foreign_keys_info: Dict) -> Schema:
    """
    Build a Schema object from database introspection results.
    
    Args:
        tables_info: Dict mapping table names to lists of column info dicts
                    Each column dict has: name, type, notnull, pk, dflt_value
        foreign_keys_info: Dict mapping table names to lists of FK info dicts
                          Each FK dict has: table, from, to
    
    Returns:
        Complete Schema object with types, fields, links, and backlinks
    """
    schema = Schema()
    
    # First pass: Create object types with fields
    for table_name, columns in tables_info.items():
        type_name = table_name_to_type_name(table_name)
        obj_type = ObjectType(name=type_name, table_name=table_name)
        
        for col in columns:
            field_name = column_name_to_field_name(col['name'])
            field_type = FieldType.from_sql_type(col['type'])
            
            field_obj = Field(
                name=field_name,
                type=field_type,
                nullable=not col['notnull'] and not col['pk'],
                is_primary_key=bool(col['pk']),
                sql_column_name=col['name']
            )
            obj_type.add_field(field_obj)
        
        schema.add_object_type(obj_type)
    
    # Second pass: Add links and backlinks based on foreign keys
    for source_table, fks in foreign_keys_info.items():
        source_type_name = table_name_to_type_name(source_table)
        source_type = schema.get_object_type(source_type_name)
        
        if not source_type:
            continue
        
        for fk in fks:
            target_table = fk['table']
            target_type_name = table_name_to_type_name(target_table)
            target_type = schema.get_object_type(target_type_name)
            
            if not target_type:
                continue
            
            # Create forward link
            link_name = infer_link_name(fk['from'], target_table)
            link = Link(
                name=link_name,
                target_type=target_type_name,
                source_column=fk['from'],
                target_column=fk['to'],
                cardinality='single'
            )
            source_type.add_link(link)
            
            # Create backlink on target type
            backlink_name = infer_backlink_name(source_table)
            backlink = BackLink(
                name=backlink_name,
                source_type=source_type_name,
                forward_link_name=link_name,
                cardinality='multi'
            )
            target_type.add_backlink(backlink)
    
    return schema
