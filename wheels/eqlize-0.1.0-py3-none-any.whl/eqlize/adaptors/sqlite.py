"""SQLite database adaptor and dialect implementation."""

import sqlite3
import json
import hashlib
from typing import List, Dict, Any, Tuple, Optional
from .base import DatabaseAdaptor, SQLDialect
from ..schema import Schema, build_schema_from_introspection


class SQLiteAdaptor(DatabaseAdaptor):
    """SQLite runtime adaptor."""
    
    def connect(self):
        self.connection = sqlite3.connect(self.connection_string)
        self.connection.row_factory = sqlite3.Row
    
    def disconnect(self):
        if self.connection:
            self.connection.close()
            self.connection = None
    
    def introspect_schema(self) -> Schema:
        """
        Introspect SQLite database to build Schema.
        
        Returns:
            Complete Schema object
        """
        if not self.connection:
            self.connect()
        
        assert self.connection is not None
        cursor = self.connection.cursor()
        
        # Get all tables
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name NOT LIKE 'sqlite_%'
        """)
        tables = [row[0] for row in cursor.fetchall()]
        
        # Get column info for each table
        tables_info = {}
        for table in tables:
            cursor.execute(f"PRAGMA table_info({table})")
            columns = []
            for row in cursor.fetchall():
                columns.append({
                    'name': row[1],
                    'type': row[2],
                    'notnull': row[3],
                    'dflt_value': row[4],
                    'pk': row[5]
                })
            tables_info[table] = columns
        
        # Get foreign key info for each table
        foreign_keys_info = {}
        for table in tables:
            cursor.execute(f"PRAGMA foreign_key_list({table})")
            fks = []
            for row in cursor.fetchall():
                fks.append({
                    'table': row[2],  # referenced table
                    'from': row[3],   # source column
                    'to': row[4]      # target column
                })
            if fks:
                foreign_keys_info[table] = fks
        
        # Build and return schema
        return build_schema_from_introspection(tables_info, foreign_keys_info)
    
    def execute_query(self, sql: str) -> List[Dict[str, Any]]:
        if not self.connection:
            self.connect()
        assert self.connection
        cursor = self.connection.cursor()
        cursor.execute(sql)
        
        results = []
        for row in cursor.fetchall():
            row_dict = dict(row)
            # SQLite specific: JSON is returned as strings, need parsing
            for key, value in row_dict.items():
                if isinstance(value, str) and (value.startswith('[') or value.startswith('{')):
                    try:
                        row_dict[key] = json.loads(value)
                    except (json.JSONDecodeError, ValueError):
                        pass
            results.append(row_dict)
        return results


class SQLiteDialect(SQLDialect):
    """SQLite compilation logic."""

    def quote_identifier(self, identifier: str) -> str:
        return f'"{identifier}"'

    def quote_literal(self, value: Any) -> str:
        if value is None:
            return 'NULL'
        if isinstance(value, bool):
            return '1' if value else '0'
        if isinstance(value, (int, float)):
            return str(value)
        return "'" + str(value).replace("'", "''") + "'"

    def validate_operator(self, operator: str) -> None:
        supported = ['=', '!=', '<', '>', '<=', '>=', 'AND', 'OR', 'NOT', 'LIKE', 'IS', 'IS NOT']
        if operator.upper() not in supported:
            raise ValueError(f"SQLite does not support operator: {operator}")

    def limit_offset(self, limit: Optional[int], offset: Optional[int]) -> str:
        clause = ""
        if limit is not None:
            clause += f"LIMIT {limit} "
        elif offset is not None:
            clause += "LIMIT -1 " # SQLite hack
        
        if offset is not None:
            clause += f"OFFSET {offset}"
        return clause.strip()

    # --- JSON ---

    def build_json_object(self, key_value_pairs: List[Tuple[str, str]]) -> str:
        args = []
        for k, v in key_value_pairs:
            args.append(f"'{k}'")
            args.append(v)
        return f"json_object({', '.join(args)})"

    def build_json_array_agg(self, expression: str, distinct: bool = False, order_by: Optional[str] = None) -> str:
        """
        SQLite implementation of JSON array aggregation.
        Note: json_group_array does NOT support DISTINCT.
        Workaround: Use json('[' || group_concat(distinct json_quote(expr)) || ']')
        """
        if distinct:
            # 1. json_quote(X) converts X into its JSON string representation.
            #    e.g. 'str' -> '"str"', 123 -> '123'
            json_val = f"json_quote({expression})"
            
            # 2. Ensure actual NULLs are skipped by GROUP_CONCAT (it skips NULL inputs).
            #    We check expression IS NOT NULL because json_quote(NULL) returns the string 'null'.
            safe_expr = f"CASE WHEN ({expression}) IS NOT NULL THEN {json_val} END"
            
            # 3. Join unique JSON elements with comma.
            concat = f"GROUP_CONCAT(DISTINCT {safe_expr})"
            
            # 4. Wrap in brackets and handle empty case (returning '[]' instead of NULL).
            return f"json(COALESCE('[' || {concat} || ']', '[]'))"
        
        # Standard aggregation
        return f"json_group_array({expression})"

    def build_json_array_subquery(self, subquery_sql: str, agg_alias: str) -> str:
        # Wrap agg_alias in json() to ensure SQLite treats the TEXT result from subquery as JSON structure
        return f"(SELECT json_group_array(json({agg_alias})) FROM ({subquery_sql}) AS _sub)"

    def extract_json_element(self, json_expr: str, index: int) -> str:
        if index < 0:
            return f"json_extract({json_expr}, '$[' || (json_array_length({json_expr}) + {index}) || ']')"
        return f"json_extract({json_expr}, '$[{index}]')"

    # --- Functions ---

    def compile_function(self, func_name: str, args: List[str], ctx_ctes: Dict[str, str]) -> str:
        func = func_name.lower()
        
        if func == 'str_split':
            string_sql, delim_sql = args[0], args[1]
            h = hashlib.md5((string_sql + delim_sql).encode()).hexdigest()[:8]
            cte_name = f"split_{h}"
            
            cte_sql = f"""
                SELECT 0 AS idx, 
                       CASE WHEN instr({string_sql}, {delim_sql}) > 0 
                            THEN substr({string_sql}, 1, instr({string_sql}, {delim_sql}) - 1)
                            ELSE {string_sql}
                       END AS str,
                       CASE WHEN instr({string_sql}, {delim_sql}) > 0
                            THEN substr({string_sql}, instr({string_sql}, {delim_sql}) + length({delim_sql}))
                            ELSE NULL
                       END AS rest
                UNION ALL
                SELECT idx + 1,
                       CASE WHEN instr(rest, {delim_sql}) > 0
                            THEN substr(rest, 1, instr(rest, {delim_sql}) - 1)
                            ELSE rest
                       END,
                       CASE WHEN instr(rest, {delim_sql}) > 0
                            THEN substr(rest, instr(rest, {delim_sql}) + length({delim_sql}))
                            ELSE NULL
                       END
                FROM {cte_name}
                WHERE rest IS NOT NULL
            """
            
            ctx_ctes[cte_name] = cte_sql
            return f"(SELECT json_group_array(str) FROM {cte_name})"

        mapping = {
            'len': 'LENGTH',
            'length': 'LENGTH',
            'upper': 'UPPER',
            'lower': 'LOWER',
            'trim': 'TRIM'
        }
        sql_func = mapping.get(func, func.upper())
        return f"{sql_func}({', '.join(args)})"

    def compile_slice(self, base_sql: str, start: Optional[int], end: Optional[int], is_array: bool) -> str:
        if is_array:
            return f"json_extract({base_sql}, '$')"
             
        if start is None and end is None:
            return base_sql
            
        start_sql = "1"
        length_sql = None
        
        if start is not None:
            if start < 0:
                start_sql = str(start)
            else:
                start_sql = str(start + 1)
        
        if end is not None:
            if end < 0 and (start is None or start >= 0):
                 length_sql = f"(LENGTH({base_sql}) + {end} - ({start_sql}) + 1)"
            elif end < 0 and start is not None and start < 0:
                length_sql = str(end - start)
            else:
                 if start is None or start == 0:
                     length_sql = str(end)
                 else:
                     length_sql = str(end - start)
                     
        if length_sql:
            return f"SUBSTR({base_sql}, {start_sql}, {length_sql})"
        return f"SUBSTR({base_sql}, {start_sql})"