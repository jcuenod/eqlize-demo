"""
Generic SQL query generation from EdgeQL AST.
Decoupled from specific SQL dialects via the SQLDialect interface.
"""

from typing import List, Dict, Tuple, Optional, Union, Any
from dataclasses import dataclass
import json

from ..parser.ast_nodes import (
    SelectQuery, Shape, ShapeElement, ShapeModifiers, WildcardElement,
    Expression, PathExpression, LiteralExpression, IdentifierExpression,
    BinaryOpExpression, UnaryOpExpression, FunctionCall,
    GroupQuery, GroupShapeElement, AggregateFunction,
    IndexExpression, SliceExpression
)
from ..schema import Schema, ObjectType, Link, BackLink
from ..adaptors.base import SQLDialect


@dataclass
class LinkInfo:
    """Metadata about a link or backlink relationship."""
    source_column: str
    target_column: str
    is_many: bool


@dataclass
class AggregateInfo:
    """Metadata about a computed aggregate column."""
    sql_expression: str
    function_name: str
    argument_sql: str
    has_distinct: bool = False


class CompilerContext:
    """Context for tracking state during compilation."""
    
    def __init__(self, schema: Schema, dialect: SQLDialect):
        self.schema = schema
        self.dialect = dialect
        self.table_aliases: Dict[str, str] = {}
        self.alias_to_type: Dict[str, ObjectType] = {}
        self.alias_counter = 0
        self.joins: List[Tuple[str, str, str]] = []
        self.selected_columns: List[str] = []
        self.current_table_alias: Optional[str] = None
        self.has_backlinks: bool = False
        self.group_by_columns: List[str] = []
        self.relationship_modifiers: Dict[str, ShapeModifiers] = {}
        self.computed_columns: Dict[str, str] = {}
        self.computed_aggregates: Dict[str, AggregateInfo] = {}
        self.ctes: Dict[str, str] = {}
    
    def get_next_alias(self) -> str:
        self.alias_counter += 1
        return f"t{self.alias_counter}"
    
    def add_table_alias(self, table_name: str) -> str:
        if table_name not in self.table_aliases:
            alias = self.get_next_alias()
            self.table_aliases[table_name] = alias
        return self.table_aliases[table_name]


class SQLCompiler:
    """Compiles EdgeQL AST to SQL queries via a plugged-in SQLDialect."""
    
    def __init__(self, schema: Schema, dialect: SQLDialect):
        self.schema = schema
        self.dialect = dialect
    
    def _quote(self, identifier: str) -> str:
        return self.dialect.quote_identifier(identifier)

    def _qualified_column(self, table_alias: str, column_name: str) -> str:
        return f"{table_alias}.{self._quote(column_name)}"

    def _append_projection(self, ctx: CompilerContext, sql_expression: str, alias: str) -> None:
        ctx.selected_columns.append(f"{sql_expression} AS {self._quote(alias)}")

    def _get_object_type_or_error(self, type_name: str) -> ObjectType:
        obj_type = self.schema.get_object_type(type_name)
        if not obj_type:
            raise ValueError(f"Unknown object type: {type_name}")
        return obj_type

    def _suggest_properties(self, available: List[str], invalid_name: str) -> List[str]:
        def levenshtein_distance(s1: str, s2: str) -> int:
            if len(s1) < len(s2):
                return levenshtein_distance(s2, s1)
            if not s2:
                return len(s1)
            previous_row = list(range(len(s2) + 1))
            for i, c1 in enumerate(s1):
                current_row = [i + 1]
                for j, c2 in enumerate(s2):
                    insertions = previous_row[j + 1] + 1
                    deletions = current_row[j] + 1
                    substitutions = previous_row[j] + (c1 != c2)
                    current_row.append(min(insertions, deletions, substitutions))
                previous_row = current_row
            return previous_row[-1]

        suggestions: List[Tuple[int, str]] = []
        lowered_invalid = invalid_name.lower()
        for prop in available:
            distance = levenshtein_distance(lowered_invalid, prop.lower())
            if distance <= 2 or lowered_invalid in prop.lower():
                suggestions.append((distance, prop))
        suggestions.sort(key=lambda item: item[0])
        return [name for _, name in suggestions[:3]]

    def _raise_unknown_property(self, obj_type: ObjectType, property_name: str) -> None:
        available = list(obj_type.fields.keys()) + list(obj_type.links.keys()) + list(obj_type.backlinks.keys())
        suggested_names = self._suggest_properties(available, property_name)
        msg = f"Unknown property '{property_name}' on type '{obj_type.name}'."
        if suggested_names:
            msg += f" Did you mean: {', '.join(suggested_names)}?"
        else:
            msg += f" Available properties: {', '.join(sorted(available))}"
        raise ValueError(msg)

    def compile(self, ast: Union[SelectQuery, GroupQuery]) -> str:
        if isinstance(ast, GroupQuery):
            return self.compile_group(ast)
        else:
            return self.compile_select(ast)
    
    def restructure_results(self, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not results:
            return results
        restructured = []
        for row in results:
            new_row = {}
            for key, value in row.items():
                if isinstance(value, str) and (value.startswith('[') or value.startswith('{')):
                    try:
                        parsed = json.loads(value)
                        if isinstance(parsed, list):
                            parsed = [item for item in parsed if item is not None]
                        new_row[key] = parsed
                    except (json.JSONDecodeError, ValueError):
                        new_row[key] = value
                elif isinstance(value, list):
                    new_row[key] = [item for item in value if item is not None]
                else:
                    new_row[key] = value
            restructured.append(new_row)
        return restructured
    
    def compile_select(self, ast: SelectQuery) -> str:
        ctx = CompilerContext(self.schema, self.dialect)
        obj_type = self._get_object_type_or_error(ast.target.name)
        
        main_alias = ctx.add_table_alias(obj_type.table_name)
        ctx.alias_to_type[main_alias] = obj_type
        ctx.current_table_alias = main_alias
        
        main_table_fields = [
            self._qualified_column(main_alias, field.sql_column_name)
            for field in obj_type.fields.values()
        ]
        
        if ast.shape:
            self._process_shape(ctx, obj_type, ast.shape, main_alias)
        else:
            for field_name, field in obj_type.fields.items():
                column_sql = self._qualified_column(main_alias, field.sql_column_name)
                self._append_projection(ctx, column_sql, field_name)
        
        ctx.group_by_columns = main_table_fields
        
        where_clause = None
        if ast.filter:
            where_clause = self._compile_expression(ctx, ast.filter.expression, main_alias)
        
        order_by = None
        if ast.order_by:
            order_by = []
            for order_expr in ast.order_by.expressions:
                expr_sql = self._compile_expression(ctx, order_expr.expression, main_alias)
                order_by.append(f"{expr_sql} {order_expr.direction}")
        
        limit = ast.limit.value if ast.limit else None
        offset = ast.offset.value if ast.offset else None
        
        table_with_alias = f"{self._quote(obj_type.table_name)} AS {main_alias}"
        sql_parts = []
        
        if ctx.ctes:
            cte_definitions = [f"{name} AS ({sql})" for name, sql in ctx.ctes.items()]
            sql_parts.append(f"WITH RECURSIVE {', '.join(cte_definitions)}")
        
        sql_parts.append('SELECT')
        sql_parts.append('  ' + ',\n  '.join(ctx.selected_columns))
        sql_parts.append(f'FROM {table_with_alias}')
        
        if ctx.joins:
            for join_type, join_table, join_condition in ctx.joins:
                sql_parts.append(f'{join_type} {join_table} ON {join_condition}')
        
        if where_clause:
            sql_parts.append(f'WHERE {where_clause}')
        
        if ctx.has_backlinks and ctx.group_by_columns:
            sql_parts.append(f'GROUP BY {", ".join(ctx.group_by_columns)}')
            
        if order_by:
            sql_parts.append(f'ORDER BY {", ".join(order_by)}')
            
        limit_offset_clause = self.dialect.limit_offset(limit, offset)
        if limit_offset_clause:
            sql_parts.append(limit_offset_clause)
            
        return '\n'.join(sql_parts)
    
    def compile_group(self, ast: GroupQuery) -> str:
        ctx = CompilerContext(self.schema, self.dialect)
        obj_type = self._get_object_type_or_error(ast.target.name)
        
        main_alias = ctx.add_table_alias(obj_type.table_name)
        ctx.alias_to_type[main_alias] = obj_type
        ctx.current_table_alias = main_alias
        
        elements_to_process = []
        if ast.shape:
            # Collect explicit element names so wildcard expansion doesn't duplicate them.
            explicit_names = set()
            for element in ast.shape.elements:
                if hasattr(element, 'name') and not isinstance(element, WildcardElement):
                    explicit_names.add(element.name)

            for element in ast.shape.elements:
                if isinstance(element, WildcardElement):
                    for field_name in obj_type.fields.keys():
                        if field_name not in explicit_names:
                            elements_to_process.append(GroupShapeElement(name=field_name))
                else:
                    elements_to_process.append(element)
        
        if not elements_to_process and ast.group_by:
            for expr in ast.group_by.expressions:
                if isinstance(expr, PathExpression) and len(expr.path) == 1:
                    field_name = expr.path[0]
                    elements_to_process.append(GroupShapeElement(name=field_name))
        
        for element in elements_to_process:
            if hasattr(element, 'is_assignment') and element.is_assignment and element.expression:
                alias_name = element.name
                if isinstance(element.expression, AggregateFunction):
                    agg_sql, agg_info = self._compile_aggregate(ctx, element.expression, main_alias)
                    self._append_projection(ctx, agg_sql, alias_name)
                    ctx.computed_columns[alias_name] = agg_sql
                    ctx.computed_aggregates[alias_name] = agg_info
                elif isinstance(element.expression, FunctionCall):
                    func_name = element.expression.function_name.lower()
                    aggregate_function_names = {'count', 'sum', 'avg', 'min', 'max', 'list'}
                    if func_name in aggregate_function_names:
                        if not element.expression.arguments:
                            raise ValueError(f"Aggregate function {func_name} requires an argument")
                        agg = AggregateFunction(
                            function_name=element.expression.function_name,
                            argument=element.expression.arguments[0],
                            filter=None
                        )
                        agg_sql, agg_info = self._compile_aggregate(ctx, agg, main_alias)
                        self._append_projection(ctx, agg_sql, alias_name)
                        ctx.computed_columns[alias_name] = agg_sql
                        ctx.computed_aggregates[alias_name] = agg_info
                    else:
                        expr_sql = self._compile_expression(ctx, element.expression, main_alias)
                        self._append_projection(ctx, expr_sql, alias_name)
                        ctx.computed_columns[alias_name] = expr_sql
                else:
                    expr_sql = self._compile_expression(ctx, element.expression, main_alias)
                    self._append_projection(ctx, expr_sql, alias_name)
                    ctx.computed_columns[alias_name] = expr_sql
            elif element.shape:
                if element.name in obj_type.links:
                    link = obj_type.links[element.name]
                    self._process_link(ctx, obj_type, link, element, main_alias)
                elif element.name in obj_type.backlinks:
                    backlink = obj_type.backlinks[element.name]
                    shape_elem = ShapeElement(name=element.name, shape=element.shape)
                    self._process_backlink(ctx, obj_type, backlink, shape_elem, main_alias)
            else:
                field_name = element.name
                if field_name in obj_type.fields:
                    field = obj_type.fields[field_name]
                    column_sql = self._qualified_column(main_alias, field.sql_column_name)
                    self._append_projection(ctx, column_sql, field_name)
        
        group_by_exprs = []
        if ast.group_by:
            for expr in ast.group_by.expressions:
                group_by_sql = self._compile_expression(ctx, expr, main_alias)
                group_by_exprs.append(group_by_sql)
        
        table_with_alias = f"{self._quote(obj_type.table_name)} AS {main_alias}"
        sql_parts = []
        
        if ctx.ctes:
            cte_definitions = [f"{name} AS ({sql})" for name, sql in ctx.ctes.items()]
            sql_parts.append(f"WITH RECURSIVE {', '.join(cte_definitions)}")
            
        sql_parts.append('SELECT')
        sql_parts.append('  ' + ',\n  '.join(ctx.selected_columns))
        sql_parts.append(f'FROM {table_with_alias}')
        
        if ctx.joins:
            for join_type, join_table, join_condition in ctx.joins:
                sql_parts.append(f'{join_type} {join_table} ON {join_condition}')
        
        where_conditions = []
        having_conditions = []
        if ast.filter:
            if self._expression_references_computed_columns(ctx, ast.filter.expression):
                having_sql = self._compile_group_filter_expression(ctx, ast.filter.expression, main_alias)
                having_conditions.append(having_sql)
            else:
                where_sql = self._compile_expression(ctx, ast.filter.expression, main_alias)
                where_conditions.append(where_sql)
        
        if where_conditions:
            sql_parts.append(f'WHERE {" AND ".join(where_conditions)}')
            
        if group_by_exprs:
            sql_parts.append(f'GROUP BY {", ".join(group_by_exprs)}')
            
        if having_conditions:
            sql_parts.append(f'HAVING {" AND ".join(having_conditions)}')
        
        if ast.order_by:
            order_exprs = []
            for order_expr in ast.order_by.expressions:
                expr_sql = self._compile_expression(ctx, order_expr.expression, main_alias)
                order_exprs.append(f'{expr_sql} {order_expr.direction}')
            sql_parts.append(f'ORDER BY {", ".join(order_exprs)}')
        
        limit = ast.limit.value if ast.limit else None
        offset = ast.offset.value if ast.offset else None
        limit_offset_clause = self.dialect.limit_offset(limit, offset)
        if limit_offset_clause:
            sql_parts.append(limit_offset_clause)
            
        return '\n'.join(sql_parts)

    def _compile_shape_to_json(self, ctx: CompilerContext, target_type: ObjectType,
                               shape: Optional[Shape], parent_alias: str,
                               link_info: Optional[LinkInfo] = None,
                               modifiers: Optional['ShapeModifiers'] = None) -> str:
        target_alias = self._quote(target_type.table_name)
        
        where_clause = None
        if link_info:
            parent_col = self._qualified_column(parent_alias, link_info.source_column)
            target_col = self._qualified_column(target_alias, link_info.target_column)
            where_clause = f"{target_col} = {parent_col}"
        
        json_fields_tuples: List[Tuple[str, str]] = []
        
        elements_to_process = []
        if shape:
            # Collect explicit element names so wildcard expansion doesn't duplicate them.
            explicit_names = set()
            for element in shape.elements:
                if hasattr(element, 'name') and not isinstance(element, WildcardElement):
                    explicit_names.add(element.name)

            for element in shape.elements:
                if isinstance(element, WildcardElement):
                    for field_name in target_type.fields.keys():
                        if field_name not in explicit_names:
                            elements_to_process.append(ShapeElement(name=field_name))
                elif isinstance(element, ShapeElement):
                    elements_to_process.append(element)
        else:
            for field_name in target_type.fields.keys():
                elements_to_process.append(ShapeElement(name=field_name))
        
        for element in elements_to_process:
            if element.name in target_type.fields:
                field = target_type.fields[element.name]
                column_ref = self._qualified_column(target_alias, field.sql_column_name)
                json_fields_tuples.append((element.name, column_ref))
            elif element.name in target_type.links:
                link = target_type.links[element.name]
                linked_type = self.schema.get_object_type(link.target_type)
                if linked_type:
                    nested_link_info = LinkInfo(link.source_column, link.target_column, False)
                    nested_json = self._compile_shape_to_json(
                        ctx, linked_type, element.shape, target_alias, nested_link_info, element.modifiers
                    )
                    json_fields_tuples.append((element.name, f"({nested_json})"))
            elif element.name in target_type.backlinks:
                backlink = target_type.backlinks[element.name]
                source_type = self.schema.get_object_type(backlink.source_type)
                if source_type and backlink.forward_link_name in source_type.links:
                    forward_link = source_type.links[backlink.forward_link_name]
                    nested_link_info = LinkInfo(forward_link.target_column, forward_link.source_column, True)
                    nested_json = self._compile_shape_to_json(
                        ctx, source_type, element.shape, target_alias, nested_link_info, element.modifiers
                    )
                    json_fields_tuples.append((element.name, f"({nested_json})"))
        
        if not json_fields_tuples:
            return "NULL"
        
        json_obj = self.dialect.build_json_object(json_fields_tuples)
        from_clause = f"{self._quote(target_type.table_name)} AS {target_alias}"
        
        where_conditions = []
        if where_clause:
            where_conditions.append(where_clause)
        if modifiers and modifiers.filter:
            filter_sql = self._compile_expression(ctx, modifiers.filter.expression, target_alias)
            where_conditions.append(filter_sql)
        
        order_by_sql = None
        if modifiers and modifiers.order_by:
            order_by_parts = []
            for order_expr in modifiers.order_by.expressions:
                expr_sql = self._compile_expression(ctx, order_expr.expression, target_alias)
                order_by_parts.append(f"{expr_sql} {order_expr.direction}")
            order_by_sql = ', '.join(order_by_parts)
        
        limit_value = modifiers.limit.value if modifiers and modifiers.limit else None
        if limit_value is None and link_info and not link_info.is_many:
            limit_value = 1
        
        offset_value = modifiers.offset.value if modifiers and modifiers.offset else None
        
        if link_info and link_info.is_many:
            # We explicitly alias the inner JSON object column as _json_element
            json_select_parts = [f"SELECT {json_obj} AS _json_element FROM {from_clause}"]
            if where_conditions:
                json_select_parts.append(f"WHERE {' AND '.join(where_conditions)}")
            if order_by_sql:
                json_select_parts.append(f"ORDER BY {order_by_sql}")
            
            limit_offset_clause = self.dialect.limit_offset(limit_value, offset_value)
            if limit_offset_clause:
                json_select_parts.append(limit_offset_clause)
            
            json_subquery = '\n'.join(json_select_parts)
            return self.dialect.build_json_array_subquery(json_subquery, "_json_element")
        else:
            subquery = f"SELECT {json_obj} FROM {from_clause}"
            if where_conditions:
                subquery += f"\n WHERE {' AND '.join(where_conditions)}"
            if order_by_sql:
                subquery += f"\n ORDER BY {order_by_sql}"
            
            limit_offset_clause = self.dialect.limit_offset(limit_value, offset_value)
            if limit_offset_clause:
                subquery += f"\n {limit_offset_clause}"
            
            return subquery

    def _process_shape(self, ctx: CompilerContext, obj_type: ObjectType, shape: Shape, table_alias: str):
        # Precompute explicit element names to avoid duplicating fields expanded from wildcard.
        explicit_names = set()
        for el in shape.elements:
            if isinstance(el, ShapeElement) and el.name:
                explicit_names.add(el.name)

        for element in shape.elements:
            if isinstance(element, WildcardElement):
                for field_name, field in obj_type.fields.items():
                    if field_name in explicit_names:
                        continue
                    column_sql = self._qualified_column(table_alias, field.sql_column_name)
                    self._append_projection(ctx, column_sql, field_name)
            
            elif isinstance(element, ShapeElement):
                if element.expression:
                    expr_sql = self._compile_expression(ctx, element.expression, table_alias)
                    self._append_projection(ctx, expr_sql, element.alias or element.name)
                elif element.name in obj_type.fields:
                    field = obj_type.fields[element.name]
                    column_sql = self._qualified_column(table_alias, field.sql_column_name)
                    self._append_projection(ctx, column_sql, element.alias or element.name)
                elif element.name in obj_type.links:
                    if element.modifiers:
                        ctx.relationship_modifiers[element.name] = element.modifiers
                    self._process_link(ctx, obj_type, obj_type.links[element.name], element, table_alias)
                elif element.name in obj_type.backlinks:
                    if element.modifiers:
                        ctx.relationship_modifiers[element.name] = element.modifiers
                    self._process_backlink(ctx, obj_type, obj_type.backlinks[element.name], element, table_alias)
                else:
                    self._raise_unknown_property(obj_type, element.name)

    def _process_link(self, ctx: CompilerContext, source_type: ObjectType, link: Link, 
                     element: Union[ShapeElement, GroupShapeElement], source_alias: str):
        target_type = self.schema.get_object_type(link.target_type)
        if not target_type:
            return
        
        link_info = LinkInfo(link.source_column, link.target_column, False)
        modifiers = getattr(element, 'modifiers', None)
        
        json_subquery = self._compile_shape_to_json(ctx, target_type, element.shape, source_alias, link_info, modifiers)
        self._append_projection(ctx, f"({json_subquery})", element.name)

    def _process_backlink(self, ctx: CompilerContext, target_type: ObjectType, backlink: BackLink,
                         element: ShapeElement, target_alias: str):
        source_type = self.schema.get_object_type(backlink.source_type)
        if not source_type or backlink.forward_link_name not in source_type.links:
            return
        
        forward_link = source_type.links[backlink.forward_link_name]
        link_info = LinkInfo(forward_link.target_column, forward_link.source_column, True)
        modifiers = getattr(element, 'modifiers', None)
        
        json_subquery = self._compile_shape_to_json(ctx, source_type, element.shape, target_alias, link_info, modifiers)
        self._append_projection(ctx, f"({json_subquery})", element.name)

    def _compile_function_call(self, ctx: CompilerContext, func: FunctionCall, table_alias: str) -> str:
        relationship_functions = {'count', 'sum', 'avg', 'min', 'max', 'exists'}
        has_relationship_arg = False
        if (func.arguments and isinstance(func.arguments[0], PathExpression) and 
            func.function_name.lower() in relationship_functions):
            path_name = func.arguments[0].path[0]
            obj_type = ctx.alias_to_type.get(table_alias)
            if obj_type:
                has_relationship_arg = (path_name in obj_type.links or path_name in obj_type.backlinks)
        
        if has_relationship_arg:
            return self._compile_relationship_function(ctx, func, table_alias)
            
        args = []
        for arg in func.arguments:
            args.append(self._compile_expression(ctx, arg, table_alias))
        
        return self.dialect.compile_function(func.function_name, args, ctx.ctes)

    def _compile_relationship_function(self, ctx: CompilerContext, func: FunctionCall, table_alias: str) -> str:
        func_name = func.function_name.lower()
        arg = func.arguments[0]
        if not isinstance(arg, PathExpression):
            raise ValueError(f"Expected PathExpression as argument to {func_name}")
        path_name = arg.path[0]
        obj_type = ctx.alias_to_type.get(table_alias)
        
        if not obj_type:
            raise ValueError(f"Unknown table alias: {table_alias}")
        
        if path_name in obj_type.backlinks:
            backlink = obj_type.backlinks[path_name]
            source_type = self.schema.get_object_type(backlink.source_type)
            if not source_type:
                raise ValueError(f"Unknown source type: {backlink.source_type}")
            forward_link = source_type.links[backlink.forward_link_name]
            
            source_table = self._quote(source_type.table_name)
            source_col = self._quote(forward_link.source_column)
            parent_col = self._qualified_column(table_alias, forward_link.target_column)
            
            if func_name == 'exists':
                return f"EXISTS (SELECT 1 FROM {source_table} WHERE {source_table}.{source_col} = {parent_col})"
            elif func_name == 'count':
                where_conditions = [f"{source_table}.{source_col} = {parent_col}"]
                if path_name in ctx.relationship_modifiers:
                    modifiers = ctx.relationship_modifiers[path_name]
                    if modifiers.filter:
                        filter_sql = self._compile_expression(ctx, modifiers.filter.expression, source_table)
                        where_conditions.append(f"({filter_sql})")
                return f"(SELECT COUNT(*) FROM {source_table} WHERE {' AND '.join(where_conditions)})"
            elif func_name in ('sum', 'avg', 'min', 'max'):
                if len(func.arguments) < 2:
                    raise ValueError(f"{func_name} requires field argument")
                field_arg = func.arguments[1]
                if not isinstance(field_arg, PathExpression):
                    raise ValueError(f"{func_name} requires a path expression as field argument")
                field_name = field_arg.path[0]
                field_col = self._quote(source_type.fields[field_name].sql_column_name)
                return f"(SELECT {func_name.upper()}({source_table}.{field_col}) FROM {source_table} WHERE {source_table}.{source_col} = {parent_col})"
        
        elif path_name in obj_type.links:
            link = obj_type.links[path_name]
            fk_col = self._qualified_column(table_alias, link.source_column)
            if func_name == 'exists':
                return f"{fk_col} IS NOT NULL"
            elif func_name == 'count':
                return f"CASE WHEN {fk_col} IS NOT NULL THEN 1 ELSE 0 END"
        
        raise ValueError(f"Path '{path_name}' is not a valid relationship for {func_name}")

    def _compile_index_expression(self, ctx: CompilerContext, expr: IndexExpression, table_alias: str) -> str:
        base_sql = self._compile_expression(ctx, expr.expression, table_alias)
        is_array = self._is_array_expression(expr.expression)
        
        if is_array:
            return self.dialect.extract_json_element(base_sql, expr.index)
        else:
            return self.dialect.compile_slice(base_sql, expr.index, expr.index + 1 if expr.index != -1 else None, False)

    def _compile_slice_expression(self, ctx: CompilerContext, expr: SliceExpression, table_alias: str) -> str:
        base_sql = self._compile_expression(ctx, expr.expression, table_alias)
        is_array = self._is_array_expression(expr.expression)
        return self.dialect.compile_slice(base_sql, expr.start, expr.end, is_array)

    def _is_array_expression(self, expr: Expression) -> bool:
        if isinstance(expr, FunctionCall) and expr.function_name.lower() == 'str_split':
            return True
        if isinstance(expr, SliceExpression):
            return self._is_array_expression(expr.expression)
        return False

    def _compile_aggregate(self, ctx: CompilerContext, agg: AggregateFunction, table_alias: str) -> Tuple[str, AggregateInfo]:
        arg_sql = self._compile_expression(ctx, agg.argument, table_alias)
        func_name = agg.function_name.lower()
        
        if func_name == 'list':
            if agg.filter:
                filter_expr = self._compile_expression(ctx, agg.filter.expression, table_alias)
                arg_sql = f"CASE WHEN {filter_expr} THEN {arg_sql} END"
            
            # Pass distinct flag to dialect
            sql_expression = self.dialect.build_json_array_agg(arg_sql, agg.distinct)
            info = AggregateInfo(sql_expression, func_name, arg_sql, agg.distinct)
            return sql_expression, info
        
        sql_func = func_name.upper()
        base_arg_sql = arg_sql
        
        if agg.filter:
            filter_expr = self._compile_expression(ctx, agg.filter.expression, table_alias)
            arg_sql = f"CASE WHEN {filter_expr} THEN {arg_sql} END"
            
        if agg.distinct:
            arg_sql = f"DISTINCT {arg_sql}"
            
        sql_expression = f"{sql_func}({arg_sql})"
        return sql_expression, AggregateInfo(sql_expression, func_name, base_arg_sql, agg.distinct)

    def _expression_references_computed_columns(self, ctx: CompilerContext, expr: Expression) -> bool:
        if isinstance(expr, FunctionCall):
            return any(self._expression_references_computed_columns(ctx, arg) for arg in expr.arguments)
        if isinstance(expr, PathExpression):
            return len(expr.path) == 1 and expr.path[0] in ctx.computed_columns
        if isinstance(expr, BinaryOpExpression):
            return (self._expression_references_computed_columns(ctx, expr.left) or 
                    self._expression_references_computed_columns(ctx, expr.right))
        if isinstance(expr, UnaryOpExpression):
            return self._expression_references_computed_columns(ctx, expr.operand)
        return False

    def _compile_group_filter_expression(self, ctx: CompilerContext, expr: Expression, table_alias: str) -> str:
        """Compile filter specifically for HAVING clauses, handling computed columns and aggregates."""
        
        # 1. Direct reference to a computed column
        if isinstance(expr, PathExpression) and len(expr.path) == 1 and expr.path[0] in ctx.computed_columns:
            alias = expr.path[0]
            if alias in ctx.computed_aggregates:
                # Updated error message to match test expectation regarding 'function' or 'count'
                raise ValueError(
                    f"Cannot reference aggregate '{alias}' directly in filter. "
                    f"Use an aggregate function like count(.{alias}) instead."
                )
            return self._quote(alias)
            
        # 2. Function calls (aggregates on aggregates)
        if isinstance(expr, FunctionCall):
            # Check if this is an aggregate function operating on a computed aggregate column
            # e.g. count(.pl) where pl is a computed list
            if (expr.arguments and isinstance(expr.arguments[0], PathExpression) and 
                len(expr.arguments[0].path) == 1 and expr.arguments[0].path[0] in ctx.computed_columns):
                
                alias = expr.arguments[0].path[0]
                func_name = expr.function_name.lower()
                
                # If we are doing count(.alias) and alias is a computed aggregate
                if func_name in {'count', 'sum', 'avg', 'min', 'max'} and alias in ctx.computed_aggregates:
                    agg_info = ctx.computed_aggregates[alias]
                    
                    # We need to apply the function to the underlying argument SQL, not the json_group_array result
                    if func_name == 'count':
                        distinct_clause = 'DISTINCT ' if agg_info.has_distinct else ''
                        return f"COUNT({distinct_clause}{agg_info.argument_sql})"
                    else:
                        return f"{func_name.upper()}({agg_info.argument_sql})"
        
        # 3. Binary Operators - RECURSE via _compile_group_filter_expression
        if isinstance(expr, BinaryOpExpression):
            self.dialect.validate_operator(expr.operator)
            left = self._compile_group_filter_expression(ctx, expr.left, table_alias)
            right = self._compile_group_filter_expression(ctx, expr.right, table_alias)
            return f"({left} {expr.operator} {right})"
            
        # 4. Unary Operators - RECURSE via _compile_group_filter_expression
        if isinstance(expr, UnaryOpExpression):
            operand = self._compile_group_filter_expression(ctx, expr.operand, table_alias)
            return f"({expr.operator} {operand})"
        
        # 5. Fallback for literals, standard columns, etc.
        return self._compile_expression(ctx, expr, table_alias)

    def _compile_expression(self, ctx: CompilerContext, expr: Expression, table_alias: str) -> str:
        if isinstance(expr, PathExpression):
            path = expr.path[0]
            # Validate against schema
            if table_alias in ctx.alias_to_type:
                obj_type = ctx.alias_to_type[table_alias]
                if (path not in obj_type.fields and 
                    path not in obj_type.links and 
                    path not in obj_type.backlinks):
                    self._raise_unknown_property(obj_type, path)
            return f"{table_alias}.{self._quote(path)}"
            
        elif isinstance(expr, IdentifierExpression):
            # Identifiers might be aliases or column names depending on context
            if table_alias in ctx.alias_to_type:
                obj_type = ctx.alias_to_type[table_alias]
                if (expr.name not in obj_type.fields and 
                    expr.name not in obj_type.links and 
                    expr.name not in obj_type.backlinks and
                    expr.name not in ctx.computed_columns):
                     pass # Allow if it's a known alias, but strict validation happens in PathExpression
            return self._quote(expr.name)
            
        elif isinstance(expr, LiteralExpression):
            return self.dialect.quote_literal(expr.value)
        elif isinstance(expr, BinaryOpExpression):
            self.dialect.validate_operator(expr.operator)
            left = self._compile_expression(ctx, expr.left, table_alias)
            right = self._compile_expression(ctx, expr.right, table_alias)
            return f"({left} {expr.operator} {right})"
        elif isinstance(expr, UnaryOpExpression):
            operand = self._compile_expression(ctx, expr.operand, table_alias)
            return f"({expr.operator} {operand})"
        elif isinstance(expr, FunctionCall):
            return self._compile_function_call(ctx, expr, table_alias)
        elif isinstance(expr, IndexExpression):
            return self._compile_index_expression(ctx, expr, table_alias)
        elif isinstance(expr, SliceExpression):
            return self._compile_slice_expression(ctx, expr, table_alias)
        else:
            raise ValueError(f"Unsupported expression type: {type(expr)}")