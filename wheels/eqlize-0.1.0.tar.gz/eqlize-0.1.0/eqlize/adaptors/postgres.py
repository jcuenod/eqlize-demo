"""PostgreSQL database adaptor and dialect implementation."""

from typing import List, Dict, Any, Tuple, Optional
from .base import DatabaseAdaptor, SQLDialect
from ..schema import Schema, build_schema_from_introspection


class PostgresAdaptor(DatabaseAdaptor):
    """PostgreSQL runtime adaptor."""
    
    def connect(self):
        import psycopg2
        from psycopg2.extras import RealDictCursor
        self.connection = psycopg2.connect(self.connection_string)
        self.cursor_factory = RealDictCursor
    
    def disconnect(self):
        if self.connection:
            self.connection.close()
            self.connection = None
            
    def introspect_schema(self) -> Schema:
        """
        Introspect PostgreSQL database to build Schema.
        Queries information_schema to reverse engineer the data model.
        """
        if not self.connection:
            self.connect()
            
        assert self.connection is not None
        # Use a standard cursor for introspection queries
        cursor = self.connection.cursor()
        
        # 1. Get tables and Columns
        # We gather all columns and also check primary key constraints in separate steps
        tables_info = {}
        
        # Fetch all columns for public tables
        sql_columns = """
            SELECT 
                table_name, 
                column_name, 
                data_type, 
                is_nullable, 
                column_default
            FROM information_schema.columns
            WHERE table_schema = 'public'
            ORDER BY table_name, ordinal_position
        """
        cursor.execute(sql_columns)
        columns_rows = cursor.fetchall()
        
        # Fetch Primary Keys
        sql_pks = """
            SELECT kcu.table_name, kcu.column_name
            FROM information_schema.table_constraints tco
            JOIN information_schema.key_column_usage kcu 
              ON kcu.constraint_name = tco.constraint_name
              AND kcu.constraint_schema = tco.constraint_schema
            WHERE tco.constraint_type = 'PRIMARY KEY'
              AND tco.table_schema = 'public'
        """
        cursor.execute(sql_pks)
        pk_rows = cursor.fetchall()
        
        # Organize PKs by table for easy lookup
        pks_by_table = {} # table -> set of pk columns
        for table, col in pk_rows:
            if table not in pks_by_table:
                pks_by_table[table] = set()
            pks_by_table[table].add(col)
            
        # Build tables_info dictionary
        for row in columns_rows:
            # psycopg2 (without RealDictCursor) returns tuples
            table_name = row[0]
            col_name = row[1]
            data_type = row[2]
            is_nullable = row[3] == 'YES'
            default_val = row[4]
            
            if table_name not in tables_info:
                tables_info[table_name] = []
                
            is_pk = 1 if table_name in pks_by_table and col_name in pks_by_table[table_name] else 0
            
            tables_info[table_name].append({
                'name': col_name,
                'type': data_type,
                'notnull': 0 if is_nullable else 1,
                'dflt_value': default_val,
                'pk': is_pk
            })
            
        # 2. Get Foreign Keys
        sql_fks = """
            SELECT
                tc.table_name, 
                kcu.column_name, 
                ccu.table_name AS foreign_table_name,
                ccu.column_name AS foreign_column_name
            FROM information_schema.table_constraints AS tc
            JOIN information_schema.key_column_usage AS kcu
              ON tc.constraint_name = kcu.constraint_name
              AND tc.table_schema = kcu.table_schema
            JOIN information_schema.constraint_column_usage AS ccu
              ON ccu.constraint_name = tc.constraint_name
              AND ccu.table_schema = tc.table_schema
            WHERE tc.constraint_type = 'FOREIGN KEY' 
              AND tc.table_schema = 'public'
        """
        cursor.execute(sql_fks)
        fk_rows = cursor.fetchall()
        
        foreign_keys_info = {}
        for row in fk_rows:
            table_name = row[0]
            from_col = row[1]
            to_table = row[2]
            to_col = row[3]
            
            if table_name not in foreign_keys_info:
                foreign_keys_info[table_name] = []
            
            foreign_keys_info[table_name].append({
                'table': to_table,
                'from': from_col,
                'to': to_col
            })
            
        return build_schema_from_introspection(tables_info, foreign_keys_info)
    
    def execute_query(self, sql: str) -> List[Dict[str, Any]]:
        if not self.connection:
            self.connect()
        assert self.connection is not None
        # Use the factory set in connect() to get dicts
        with self.connection.cursor(cursor_factory=self.cursor_factory) as cursor:
            cursor.execute(sql)
            results = cursor.fetchall()
            # Convert RealDictRow to standard dict
            # Postgres JSONB types are automatically parsed by psycopg2, 
            # so we don't need manual JSON parsing like SQLite.
            return [dict(row) for row in results]


class PostgresDialect(SQLDialect):
    """Postgres compilation logic."""

    def quote_identifier(self, identifier: str) -> str:
        return f'"{identifier}"'

    def quote_literal(self, value: Any) -> str:
        if value is None:
            return 'NULL'
        if isinstance(value, bool):
            return 'TRUE' if value else 'FALSE'
        if isinstance(value, (int, float)):
            return str(value)
        # Basic escaping: replace single quote with two single quotes
        return "'" + str(value).replace("'", "''") + "'"

    def validate_operator(self, operator: str) -> None:
        # Postgres supports all standard SQL operators
        pass

    def limit_offset(self, limit: Optional[int], offset: Optional[int]) -> str:
        clause = ""
        if limit is not None:
            clause += f"LIMIT {limit} "
        if offset is not None:
            clause += f"OFFSET {offset}"
        return clause.strip()

    # --- JSON ---

    def build_json_object(self, key_value_pairs: List[Tuple[str, str]]) -> str:
        # PG: jsonb_build_object(k1, v1, k2, v2)
        args = []
        for k, v in key_value_pairs:
            args.append(f"'{k}', {v}")
        return f"jsonb_build_object({', '.join(args)})"

    def build_json_array_agg(self, expression: str, distinct: bool = False, order_by: Optional[str] = None) -> str:
        # PG: jsonb_agg(DISTINCT expression ORDER BY ...)
        # Returns NULL if no rows, so we coalesce to empty array []
        
        agg_func = "jsonb_agg"
        parts = [agg_func, "("]
        
        if distinct:
            parts.append("DISTINCT ")
            
        parts.append(expression)
        
        if order_by:
            parts.append(f" ORDER BY {order_by}")
            
        parts.append(")")
        
        full_agg = "".join(parts)
        return f"COALESCE({full_agg}, '[]'::jsonb)"

    def build_json_array_subquery(self, subquery_sql: str, agg_alias: str) -> str:
        # Wrap the subquery. jsonb_agg aggregates the aliased column.
        return f"(SELECT COALESCE(jsonb_agg({agg_alias}), '[]'::jsonb) FROM ({subquery_sql}) AS _sub)"

    def extract_json_element(self, json_expr: str, index: int) -> str:
        # PG uses -> for integer index on jsonb arrays
        # Negative indexing requires Postgres 9.5+, standard syntax is just ->
        return f"({json_expr})->{index}"

    # --- Functions ---

    def compile_function(self, func_name: str, args: List[str], ctx_ctes: Dict[str, str]) -> str:
        func = func_name.lower()
        
        if func == 'str_split':
            # Postgres has native string_to_array(string, delimiter)
            # We cast to jsonb to ensure it plays nicely with other json functions
            return f"to_jsonb(string_to_array({args[0]}, {args[1]}))"

        mapping = {
            'len': 'length',
            'length': 'length',
            'str_upper': 'upper',
            'upper': 'upper',
            'lower': 'lower',
            'trim': 'trim'
        }
        sql_func = mapping.get(func, func)
        return f"{sql_func}({', '.join(args)})"

    def compile_slice(self, base_sql: str, start: Optional[int], end: Optional[int], is_array: bool) -> str:
        if is_array:
            # Postgres JSONB array slicing is not natively supported with [s:e] syntax easily.
            # It requires unnesting or a custom function.
            # For now, we fallback to just returning the array to avoid crashing,
            # acknowledging this is a limitation in this simple adaptor.
            return base_sql 
            
        # String slicing (SUBSTRING is 1-based)
        start_sql = "1"
        length_sql = None
        
        # Postgres substring(string from start for length)
        
        if start is not None:
            if start < 0:
                # Standard SQL supports 'FROM -n' relative to end? No, standard is strict.
                # PG supports 'FROM' but the logic for negative index needs calculation
                # length(str) + start + 1
                start_sql = f"(length({base_sql}) + {start} + 1)"
            else:
                start_sql = str(start + 1)
                
        if end is not None:
            if end < 0:
                # Length = len + end - (start_pos_1_based) + 1
                length_sql = f"(length({base_sql}) + {end} - ({start_sql}) + 1)"
            else:
                if start is None or start == 0:
                    length_sql = str(end)
                else:
                    length_sql = str(end - start)
        
        if length_sql:
            return f"substring({base_sql} from {start_sql} for {length_sql})"
        return f"substring({base_sql} from {start_sql})"