"""JSON output formatter for query results."""

import json
from typing import List, Dict, Any


class JSONFormatter:
    """Format query results as JSON."""
    
    @staticmethod
    def format(results: List[Dict[str, Any]], indent: int = 2) -> str:
        """
        Format query results as JSON string.
        
        Args:
            results: List of result rows as dictionaries (may contain nested lists/dicts)
            indent: Number of spaces for indentation (default: 2, use None for compact)
            
        Returns:
            JSON formatted string
        """
        return json.dumps(results, indent=indent, default=str)
    
    @staticmethod
    def to_dict(results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Return query results as Python dictionaries (pass-through for consistency).
        
        Args:
            results: List of result rows as dictionaries
            
        Returns:
            The same list of dictionaries
        """
        return results
