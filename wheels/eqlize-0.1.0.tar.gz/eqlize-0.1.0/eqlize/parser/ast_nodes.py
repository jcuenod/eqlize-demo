"""AST (Abstract Syntax Tree) node definitions for EdgeQL."""

from dataclasses import dataclass, field
from typing import List, Optional, Any, Union


@dataclass
class ASTNode:
    """Base class for all AST nodes."""
    pass


@dataclass
class Identifier(ASTNode):
    """Represents an identifier (e.g., object type name, property name)."""
    name: str


@dataclass
class Shape(ASTNode):
    """
    Represents a shape specification in EdgeQL.
    Example: { name, age, orders: { * } }
    """
    elements: List[Union['ShapeElement', 'WildcardElement']] = field(default_factory=list)


@dataclass
class ShapeModifiers(ASTNode):
    """
    Query modifiers that apply to a nested subquery.
    Example: filter .year > 2000 order by .title limit 5
    """
    filter: Optional['FilterExpression'] = None
    order_by: Optional['OrderByClause'] = None
    limit: Optional['LimitClause'] = None
    offset: Optional['OffsetClause'] = None


@dataclass
class ShapeElement(ASTNode):
    """
    An element within a shape.
    Can be a simple property name, a computed property (with expression), or a nested link with its own shape.
    Modifiers apply to the subquery for this element.
    """
    name: str  # Property or link name (or alias for computed properties)
    shape: Optional[Shape] = None  # Nested shape for links
    alias: Optional[str] = None  # Optional alias
    expression: Optional['Expression'] = None  # For computed properties (name := expression)
    modifiers: Optional[ShapeModifiers] = None  # Modifiers for nested subquery


@dataclass
class WildcardElement(ASTNode):
    """Represents * in a shape (select all fields)."""
    pass


@dataclass
class FilterExpression(ASTNode):
    """
    Represents a filter clause.
    Example: filter .name = 'John'
    """
    expression: 'Expression'


@dataclass
class OrderByClause(ASTNode):
    """
    Represents order by clause.
    Example: order by .name desc
    """
    expressions: List['OrderByExpression']


@dataclass
class OrderByExpression(ASTNode):
    """Single ordering expression."""
    expression: 'Expression'
    direction: str = 'ASC'  # 'asc' or 'desc'


@dataclass
class LimitClause(ASTNode):
    """Represents limit clause."""
    value: int


@dataclass
class OffsetClause(ASTNode):
    """Represents offset clause."""
    value: int


@dataclass
class SelectQuery(ASTNode):
    """
    Represents a select query.
    Example: select People { name, orders: { * } } filter .age > 18
    """
    target: Identifier  # Object type being selected
    shape: Optional[Shape] = None  # What to select
    filter: Optional[FilterExpression] = None
    order_by: Optional[OrderByClause] = None
    limit: Optional[LimitClause] = None
    offset: Optional[OffsetClause] = None


# Expression nodes for filter clauses

@dataclass
class Expression(ASTNode):
    """Base class for expressions."""
    pass


@dataclass
class PathExpression(Expression):
    """
    Represents a path like .name or .person.name
    """
    path: List[str]  # List of path components
    
    def __str__(self):
        return '.' + '.'.join(self.path)


@dataclass
class LiteralExpression(Expression):
    """Represents a literal value (string, number, boolean, etc.)."""
    value: Any
    
    def __str__(self):
        if isinstance(self.value, str):
            return f"'{self.value}'"
        return str(self.value)


@dataclass
class IdentifierExpression(Expression):
    """Represents an identifier in an expression context (e.g., function argument)."""
    name: str
    
    def __str__(self):
        return self.name


@dataclass
class BinaryOpExpression(Expression):
    """
    Represents a binary operation.
    Example: .age > 18, .name = 'John'
    """
    left: Expression
    operator: str  # '=', '!=', '>', '<', '>=', '<=', 'AND', 'OR', etc.
    right: Expression
    
    def __str__(self):
        return f"({self.left} {self.operator} {self.right})"


@dataclass
class UnaryOpExpression(Expression):
    """
    Represents a unary operation.
    Example: NOT .active
    """
    operator: str  # 'NOT', '-', etc.
    operand: Expression
    
    def __str__(self):
        return f"({self.operator} {self.operand})"


@dataclass
class FunctionCall(Expression):
    """
    Represents a function call.
    Example: count(Person)
    """
    function_name: str
    arguments: List[Expression] = field(default_factory=list)
    
    def __str__(self):
        args = ', '.join(str(arg) for arg in self.arguments)
        return f"{self.function_name}({args})"


@dataclass
class IndexExpression(Expression):
    """
    Represents indexing into a string or array.
    Example: .name[0], str_split(.name, " ")[1], .name[-1]
    """
    expression: Expression  # The string or array being indexed
    index: int  # The index (can be negative)
    
    def __str__(self):
        return f"{self.expression}[{self.index}]"


@dataclass
class SliceExpression(Expression):
    """
    Represents slicing a string or array.
    Example: .name[0:5], .name[2:], .name[:-3], str_split(.name, " ")[0:2]
    At least one of start or end must be present.
    """
    expression: Expression  # The string or array being sliced
    start: Optional[int] = None  # Start index (None means from beginning)
    end: Optional[int] = None  # End index (None means to end)
    
    def __str__(self):
        start_str = str(self.start) if self.start is not None else ""
        end_str = str(self.end) if self.end is not None else ""
        return f"{self.expression}[{start_str}:{end_str}]"


@dataclass
class AggregateFunction(Expression):
    """
    Represents an aggregate function with optional distinct modifier and filter.
    Examples: 
        list(.word_uid) filter .number = "sg"
        count(distinct .actors)
    """
    function_name: str  # 'list', 'count', 'sum', 'avg', etc.
    argument: Expression  # What to aggregate
    distinct: bool = False  # Whether to use DISTINCT
    filter: Optional[FilterExpression] = None  # Optional filter clause
    
    def __str__(self):
        distinct_str = "distinct " if self.distinct else ""
        result = f"{self.function_name}({distinct_str}{self.argument})"
        if self.filter:
            result += f" filter {self.filter.expression}"
        return result


@dataclass
class GroupShapeElement(ASTNode):
    """
    An element within a group shape.
    Can be a simple field, an aggregate expression with optional assignment, or a nested relationship.
    Examples: 
        - rid (simple field)
        - sg := list(word_uid) filter .number = "sg" (aggregate)
        - person: { name, email } (nested relationship)
    """
    name: str  # Property name or alias for assignment
    expression: Optional[Expression] = None  # For computed properties (after :=)
    shape: Optional['Shape'] = None  # For nested relationship traversal
    is_assignment: bool = False  # True if using := syntax
    
    def __str__(self):
        if self.is_assignment and self.expression:
            return f"{self.name} := {self.expression}"
        elif self.shape:
            return f"{self.name}: {{ ... }}"
        return self.name


@dataclass
class GroupShape(ASTNode):
    """
    Represents a shape specification in a GROUP query.
    Example: { rid, sg := list(word_uid) filter .number = "sg" }
    """
    elements: List[Union[GroupShapeElement, 'WildcardElement']] = field(default_factory=list)


@dataclass
class GroupByClause(ASTNode):
    """
    Represents group by clause.
    Example: by rid
    """
    expressions: List[Expression]


@dataclass
class GroupQuery(ASTNode):
    """
    Represents a group query.
    Example: group Word { rid, sg := list(word_uid) filter .number = "sg" } by rid filter .rid > 100 order by .rid limit 10
    """
    target: Identifier  # Object type being grouped
    shape: Optional[GroupShape] = None  # What to select/aggregate (optional)
    group_by: Optional[GroupByClause] = None  # What to group by (optional)
    filter: Optional[FilterExpression] = None
    order_by: Optional[OrderByClause] = None
    limit: Optional[LimitClause] = None
    offset: Optional[OffsetClause] = None
