"""Table output formatter for query results."""

from typing import List, Dict, Any
from tabulate import tabulate


class TableFormatter:
    """Format query results as tables with support for nested data."""
    
    @staticmethod
    def format(results: List[Dict[str, Any]], tablefmt: str = "grid") -> str:
        """
        Format query results as a table, with nested structures shown as sub-tables.
        
        Args:
            results: List of result rows as dictionaries (may contain nested lists/dicts)
            tablefmt: Table format (grid, simple, fancy_grid, etc.)
            
        Returns:
            Formatted table string
        """
        if not results:
            return "No results"
        
        # Extract headers and check for nested data
        headers = list(results[0].keys())
        
        # Separate simple and nested columns
        simple_cols = []
        nested_cols = []
        for h in headers:
            first_val = results[0][h]
            if isinstance(first_val, (list, dict)):
                nested_cols.append(h)
            else:
                simple_cols.append(h)
        
        # If no nested data, use simple formatting
        if not nested_cols:
            rows = []
            for row in results:
                rows.append([row.get(h) for h in headers])
            return tabulate(rows, headers=headers, tablefmt=tablefmt)
        
        # Format with nested data - create rows with embedded sub-tables
        output_lines = []
        
        for i, row in enumerate(results):
            # Start with a separator if not first row
            if i > 0:
                output_lines.append("")
            
            # Show simple columns for this row
            if simple_cols:
                row_header = []
                row_data = []
                for col in simple_cols:
                    row_header.append(col)
                    row_data.append(row.get(col))
                output_lines.append(tabulate([row_data], headers=row_header, tablefmt=tablefmt))
            
            # Show nested data immediately below
            for nested_col in nested_cols:
                nested_data = row.get(nested_col)
                if nested_data:
                    output_lines.append(f"  ↳ {nested_col}:")
                    
                    if isinstance(nested_data, list) and nested_data:
                        # Format list of objects as a table
                        if isinstance(nested_data[0], dict):
                            sub_headers = list(nested_data[0].keys())
                            sub_rows = []
                            for item in nested_data:
                                sub_rows.append([item.get(h) for h in sub_headers])
                            sub_table = tabulate(sub_rows, headers=sub_headers, tablefmt=tablefmt)
                            for line in sub_table.split('\n'):
                                output_lines.append(f"    {line}")
                        else:
                            # List of simple values
                            for item in nested_data:
                                output_lines.append(f"    - {item}")
                    elif isinstance(nested_data, dict):
                        # Single nested object
                        for k, v in nested_data.items():
                            output_lines.append(f"    {k}: {v}")
                elif nested_data is not None:  # Empty list
                    output_lines.append(f"  ↳ {nested_col}: (none)")
        
        return '\n'.join(output_lines)
