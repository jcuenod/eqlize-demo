"""Main entry point for eqlize."""

import sys
import argparse
from pathlib import Path
from eqlize.adaptors import SQLiteAdaptor, SQLiteDialect, PostgresAdaptor, PostgresDialect
from eqlize.repl import REPL
from eqlize.server import HTTPServer


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Eqlize - Query SQL databases with EdgeQL"
    )
    parser.add_argument(
        "database",
        help="Path to SQLite database file or PostgreSQL connection string"
    )
    parser.add_argument(
        "--db",
        default="sqlite",
        choices=["sqlite", "postgres"],
        help="Database type (default: sqlite)"
    )
    parser.add_argument(
        "--repl",
        action="store_true",
        help="Start interactive REPL mode"
    )
    parser.add_argument(
        "--serve",
        nargs="?",
        type=int,
        const=8080,
        metavar="PORT",
        help="Start HTTP server mode (default port: 8080)"
    )
    
    args = parser.parse_args()
    
    # Create adaptor and SQL generator based on database type
    if args.db == "sqlite":
        # Check if database file exists
        db_path = Path(args.database)
        if not db_path.exists():
            print(f"Error: Database file not found: {args.database}")
            sys.exit(1)
        db_adaptor = SQLiteAdaptor(str(db_path))
        sql_dialect = SQLiteDialect()
    elif args.db == "postgres":
        # For PostgreSQL, use connection string directly
        db_adaptor = PostgresAdaptor(args.database)
        sql_dialect = PostgresDialect()
    else:
        print(f"Error: Unsupported database type: {args.db}")
        sys.exit(1)
    
    # Determine mode
    if args.serve is not None:
        # Start HTTP server
        port = args.serve
        server = HTTPServer(db_adaptor, sql_dialect, port=port)
        server.start()
    elif args.repl:
        # Start REPL
        repl = REPL(db_adaptor, sql_dialect)
        repl.start()
    else:
        # Default to REPL for backward compatibility
        print("Note: Starting REPL mode by default. Use --repl or --serve in the future.")
        print()
        repl = REPL(db_adaptor, sql_dialect)
        repl.start()


if __name__ == "__main__":
    main()
