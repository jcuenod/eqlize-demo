# Eqlize

Query SQL databases using EdgeDB's EdgeQL syntax.

## What is Eqlize?

Eqlize is an EdgeQL-to-SQL compiler that lets you query existing SQL databases using EdgeQL, EdgeDB's powerful and intuitive query language. It automatically introspects your database schema to understand table structures and relationships, then translates your EdgeQL queries into optimized SQL.

**Key benefits:**
- Write elegant, composable queries with EdgeQL syntax
- Query existing SQL databases without migration
- Automatic relationship traversal and JOIN generation
- Powerful aggregation with filtered aggregates
- Interactive REPL for data exploration

## Quick Start

Install dependencies:
```bash
pip install -r requirements.txt
```

Create a sample database:
```bash
python tests/create_sample_db.py
```

**Interactive REPL Mode:**

SQLite (`--db` defaults to `sqlite`):
```bash
python -m eqlize sample.db --repl
```

PostgreSQL:
```bash
python -m eqlize "postgresql://user:password@localhost/dbname" --db postgres --repl
```

Try a query:
```edgeql
select People { 
    name, 
    age,
    orders: { product, amount }
} filter .age > 25 order by .name
```

**HTTP Server Mode:**

SQLite (`--db` defaults to `sqlite`):
```bash
python -m eqlize sample.db --serve 8080
```

PostgreSQL:
```bash
python -m eqlize "postgresql://user:password@localhost/dbname" --db postgres --serve 8080
```

Query via HTTP:
```bash
curl -X POST http://localhost:8080/query \
  -H "Content-Type: application/json" \
  -d '{"query": "select People { name, age }"}'
```

## Example Queries

**Basic selection with filtering:**
```edgeql
select People { name, email } filter .age > 25
```

**Relationship traversal:**
```edgeql
select People { 
    name,
    orders: { product, amount, status }
}
```

**Aggregation with filtered aggregates:**
```edgeql
group Orders {
    person_id,
    total := sum(.amount),
    completed := count(.id) filter .status = "completed",
    pending := count(.id) filter .status = "pending"
} by .person_id
```

## Documentation

- **[User Guide](./docs/)** - Complete EdgeQL syntax reference and examples
- **[Contributing](./CONTRIBUTING.md)** - Development setup and architecture guide

## Features

- **Automatic Schema Introspection** - Discovers tables, columns, and foreign key relationships
- **EdgeQL select Queries** - Full support for filtering, ordering, limiting
- **Relationship Traversal** - Navigate foreign keys with intuitive dot notation
- **group by Aggregation** - Powerful aggregation with multiple aggregate functions
- **Filtered Aggregates** - Apply conditions within aggregate functions
- **Interactive REPL** - Explore your database with real-time query execution
- **HTTP API Server** - RESTful endpoint for querying via HTTP with JSON responses
- **Optimized SQL Generation** - Uses JOINs with group by for efficient query execution
- **Extensible Architecture** - Adaptor pattern for multiple database backends

## How It Works

Eqlize translates EdgeQL to SQL in four steps:

1. **Schema Introspection** - Analyzes your database to discover tables, columns, and relationships
2. **Query Parsing** - Parses EdgeQL into an Abstract Syntax Tree (AST)
3. **SQL Compilation** - Transforms the AST into optimized SQL with proper JOINs
4. **Result Formatting** - Returns results as formatted tables

Example translation:
```edgeql
select People { name, orders: { product, amount } } filter .age > 25
```

Becomes optimized SQL with JOINs:
```sql
SELECT
  t1."name" AS "name",
  (
    (
      SELECT json_group_array(json(_json_element))
      FROM (
        SELECT json_object(
          'product',
          "orders"."product",
          'amount',
          "orders"."amount"
        ) AS _json_element
        FROM "orders" AS "orders"
        WHERE "orders"."person_id" = t1."id"
      ) AS _sub
    )
  ) AS "orders"
FROM "people" AS t1
WHERE (t1."age" > 25)
```

## Usage Modes

**REPL Mode** - Interactive query exploration:

SQLite (`--db` defaults to `sqlite`):

```bash
python -m eqlize sample.db --repl
```

PostgreSQL (`--db` must be set to `postgres`):
```bash
python -m eqlize "postgresql://user:password@localhost/dbname" --db postgres --repl
```

REPL commands:
- `schema` - List all available object types
- `\d TypeName` - Describe a specific type's fields and relationships
- `\q` or `exit` - Quit the REPL
- `help` - Show help information

**Server Mode** - HTTP API for programmatic access:

SQLite (`--db` defaults to `sqlite`):
```bash
python -m eqlize sample.db --serve [PORT]  # default port: 8080
```

PostgreSQL:
```bash
python -m eqlize "postgresql://user:password@localhost/dbname" --db postgres --serve [PORT]
```

HTTP endpoints:
- `GET /` - API information
- `POST /query` - Execute EdgeQL queries

Request format:
```json
{
  "query": "select People { name, age } filter .age > 25"
}
```

Response format:
```json
{
  "data": [{"name": "Alice", "age": 30}],
  "sql": "SELECT ...",
  "count": 1
}
```

## Testing

Run the comprehensive test suite (tests are located in the `tests/` directory):

```bash
pytest
```

The test suite validates all EdgeQL syntax features including select queries, filtering, aggregation, relationship traversal, and complex nested queries.

## License

MIT
