"""REPL (Read-Eval-Print Loop) for EdgeQL queries."""

from typing import Optional
from ..adaptors import DatabaseAdaptor, SQLDialect
from ..parser import EdgeQLParser
from ..core import SQLCompiler
from ..output import TableFormatter
from ..schema import Schema
from pyparsing import ParseException


class REPL:
    """Interactive EdgeQL REPL."""
    
    def __init__(self, db_adaptor: DatabaseAdaptor, sql_dialect: SQLDialect):
        self.db_adaptor = db_adaptor
        self.sql_dialect = sql_dialect
        self.parser = EdgeQLParser()
        self.schema: Optional[Schema] = None
        self.compiler: Optional[SQLCompiler] = None
        self.formatter = TableFormatter()
        self.running = True
    
    def start(self):
        """Start the REPL."""
        print("Eqlize - EdgeQL to SQL REPL")
        print("=" * 50)
        
        # Connect and introspect schema
        print("Connecting to database...")
        self.db_adaptor.connect()
        
        print("Introspecting schema...")
        self.schema = self.db_adaptor.introspect_schema()
        
        print(f"Found {len(self.schema.object_types)} object types:")
        for type_name in self.schema.object_types.keys():
            print(f"  - {type_name}")
        
        print()
        
        # Initialize compiler
        self.compiler = SQLCompiler(self.schema, self.sql_dialect)
        
        print("Ready! Type your EdgeQL queries (or 'help' for commands)")
        print()
        
        # Main REPL loop
        while self.running:
            try:
                query = self._read_query()
                if query:
                    self._process_query(query)
            except KeyboardInterrupt:
                print("\nUse 'exit' or 'quit' to exit")
            except EOFError:
                print("\nGoodbye!")
                break
        
        # Cleanup
        self.db_adaptor.disconnect()
    
    def _read_query(self) -> Optional[str]:
        """Read a query from the user."""
        try:
            query = input("edgeql> ").strip()
            return query if query else None
        except EOFError:
            return None
    
    def _process_query(self, query: str):
        """Process a single query."""
        
        # Handle special commands
        if query.lower() in ['exit', 'quit', '\\q']:
            print("Goodbye!")
            self.running = False
            return
        
        if query.lower() in ['help', '\\h', '?']:
            self._show_help()
            return
        
        if query.lower() in ['schema', '.schema', '\\d']:
            self._show_schema()
            return
        
        if query.lower().startswith('\\d '):
            # Describe specific type
            type_name = query[3:].strip()
            self._describe_type(type_name)
            return
        
        # Parse and execute EdgeQL query
        try:
            # Parse EdgeQL
            ast = self.parser.parse(query)
            # print(repr(ast))
            
            # Compile to SQL
            assert self.compiler is not None
            sql = self.compiler.compile(ast)
            
            print("\nGenerated SQL:")
            print("-" * 50)
            print(sql)
            print("-" * 50)
            print()
            
            # Execute SQL
            results = self.db_adaptor.execute_query(sql)
            
            # Restructure results based on nested shapes
            results = self.compiler.restructure_results(results)
            
            # Format and display results
            output = self.formatter.format(results)
            print(output)
            print(f"\n({len(results)} row{'s' if len(results) != 1 else ''})")
            print()
            
        except ParseException as e:
            print(f"Parse error: {e}")
            print()
        except Exception as e:
            print(f"Error: {e}")
            import traceback
            traceback.print_exc()
            print()
    
    def _show_help(self):
        """Show help information."""
        print("""
Available commands:
  help, \\h, ?          Show this help
  schema, \\d           Show all object types
  \\d <type>            Describe a specific object type
  exit, quit, \\q       Exit the REPL

EdgeQL Query Examples:
    SELECT People
    SELECT People { name, age }
    SELECT People { name, orders: { * } }
    SELECT People FILTER .age > 18
    SELECT People ORDER BY .name
    SELECT People LIMIT 10

Operators in FILTER:
  =, !=, <, >, <=, >=   Comparison
  AND, OR, NOT          Logical operators
""")
    
    def _show_schema(self):
        """Show all object types in the schema."""
        print("\nObject Types:")
        print("=" * 50)
        assert self.schema is not None
        for type_name, obj_type in self.schema.object_types.items():
            field_count = len(obj_type.fields)
            link_count = len(obj_type.links)
            print(f"{type_name:20} ({field_count} fields, {link_count} links)")
        print()
    
    def _describe_type(self, type_name: str):
        """Describe a specific object type."""
        assert self.schema is not None
        obj_type = self.schema.get_object_type(type_name)
        if not obj_type:
            print(f"Unknown type: {type_name}")
            return
        
        print(f"\nType: {obj_type.name}")
        print(f"Table: {obj_type.table_name}")
        print("=" * 50)
        
        print("\nFields:")
        for field_name, field in obj_type.fields.items():
            nullable = "nullable" if field.nullable else "required"
            pk = " [PRIMARY KEY]" if field.is_primary_key else ""
            print(f"  {field_name:20} {field.type.value:10} ({nullable}){pk}")
        
        if obj_type.links:
            print("\nLinks:")
            for link_name, link in obj_type.links.items():
                print(f"  {link_name:20} -> {link.target_type}")
        
        if obj_type.backlinks:
            print("\nBacklinks:")
            for backlink_name, backlink in obj_type.backlinks.items():
                print(f"  {backlink_name:20} <- {backlink.source_type}")
        
        print()
