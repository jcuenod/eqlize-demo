"""Output formatters module."""

from .table import TableFormatter
from .json import JSONFormatter

__all__ = ['TableFormatter', 'JSONFormatter']
